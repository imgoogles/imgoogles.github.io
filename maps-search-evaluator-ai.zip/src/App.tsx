import React, { useState, useEffect, useCallback } from 'react';
import { TaskData, TaskFormRatingState, AIEvaluationResponse, SingleResultRating } from './types';
import { PRESET_TASKS } from './presets';
import { RatingHeader } from './components/RatingHeader';
import { MapView } from './components/MapView';
import { RatingForm } from './components/RatingForm';
import { ScreenshotUploadModal } from './components/ScreenshotUploadModal';
import { AutomationHelperModal } from './components/AutomationHelperModal';
import { GuidelinesHandbookModal } from './components/GuidelinesHandbookModal';
import { ReleaseSurveyModal } from './components/ReleaseSurveyModal';
import { Sparkles, CheckCircle2, AlertCircle, RefreshCw, Cpu, Activity, ShieldCheck, Database, Terminal } from 'lucide-react';

export default function App() {
  const [currentTask, setCurrentTask] = useState<TaskData>(PRESET_TASKS[0].task);
  const [activeResultIndex, setActiveResultIndex] = useState<number>(0);
  const [formState, setFormState] = useState<TaskFormRatingState>({
    isNavigational: null,
    results: {},
  });

  const [aiEvaluation, setAiEvaluation] = useState<AIEvaluationResponse | null>(null);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [thinkingMode, setThinkingMode] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Modals
  const [isGuidelinesOpen, setIsGuidelinesOpen] = useState<boolean>(false);
  const [isScreenshotUploadOpen, setIsScreenshotUploadOpen] = useState<boolean>(false);
  const [isAutomationScriptOpen, setIsAutomationScriptOpen] = useState<boolean>(false);
  const [isReleaseSurveyOpen, setIsReleaseSurveyOpen] = useState<boolean>(false);

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Perform AI Evaluation
  const handleAutoEvaluate = useCallback(async () => {
    setIsEvaluating(true);
    try {
      const res = await fetch('/api/evaluate-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: currentTask,
          useThinking: thinkingMode,
        }),
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Evaluation failed');
      }

      const evaluation: AIEvaluationResponse = data.evaluation;
      setAiEvaluation(evaluation);

      // Auto-populate formState
      const newResults: Record<number, SingleResultRating> = {};
      evaluation.results.forEach((r) => {
        newResults[r.resultIndex] = {
          resultIndex: r.resultIndex,
          isUnexpectedLanguage: r.isUnexpectedLanguage || false,
          isClosedOrNonExistent: r.isClosedOrNonExistent || false,
          relevance: r.relevance,
          userIntentIssue: r.userIntentIssue || false,
          distanceProminenceIssue: r.distanceProminenceIssue || false,
          nameAccuracy: r.nameAccuracy,
          nameIssue: r.nameIssue || false,
          categoryIssue: r.categoryIssue || false,
          addressAccuracy: r.addressAccuracy,
          addressIssues: r.addressIssues || [],
          pinAccuracy: r.pinAccuracy,
          pinPreciseLocationIdentified: r.pinPreciseLocationIdentified ?? null,
          comment: r.suggestedComment || '',
        };
      });

      setFormState({
        isNavigational: evaluation.isNavigational,
        results: newResults,
      });

      showToast('Form automatically evaluated & filled based on March 2025 Guidelines! ✨', 'success');
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Evaluation error', 'error');
    } finally {
      setIsEvaluating(false);
    }
  }, [currentTask, thinkingMode]);

  // Load initial preset evaluation on first mount
  useEffect(() => {
    handleAutoEvaluate();
  }, [currentTask.taskId]);

  // Hotkey listener: Alt+A to auto-rate, Ctrl+V triggers screenshot modal if pasted
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'a' || e.key === 'A')) {
        e.preventDefault();
        handleAutoEvaluate();
      }
      if (e.altKey && (e.key === 'g' || e.key === 'G')) {
        e.preventDefault();
        setIsGuidelinesOpen(true);
      }
    };

    const handleGlobalPaste = (e: ClipboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          setIsScreenshotUploadOpen(true);
          break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('paste', handleGlobalPaste);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('paste', handleGlobalPaste);
    };
  }, [handleAutoEvaluate]);

  const handleSelectPreset = (task: TaskData) => {
    setCurrentTask(task);
    setActiveResultIndex(0);
    setFormState({
      isNavigational: null,
      results: {},
    });
    setAiEvaluation(null);
  };

  const handleApplyParsedTask = (task: TaskData, evaluation: AIEvaluationResponse) => {
    setCurrentTask(task);
    setActiveResultIndex(0);
    setAiEvaluation(evaluation);

    const newResults: Record<number, SingleResultRating> = {};
    evaluation.results.forEach((r) => {
      newResults[r.resultIndex] = {
        resultIndex: r.resultIndex,
        isUnexpectedLanguage: r.isUnexpectedLanguage || false,
        isClosedOrNonExistent: r.isClosedOrNonExistent || false,
        relevance: r.relevance,
        userIntentIssue: r.userIntentIssue || false,
        distanceProminenceIssue: r.distanceProminenceIssue || false,
        nameAccuracy: r.nameAccuracy,
        nameIssue: r.nameIssue || false,
        categoryIssue: r.categoryIssue || false,
        addressAccuracy: r.addressAccuracy,
        addressIssues: r.addressIssues || [],
        pinAccuracy: r.pinAccuracy,
        pinPreciseLocationIdentified: r.pinPreciseLocationIdentified ?? null,
        comment: r.suggestedComment || '',
      };
    });

    setFormState({
      isNavigational: evaluation.isNavigational,
      results: newResults,
    });

    showToast('Screenshot parsed & rating form auto-filled successfully!', 'success');
  };

  const handleSubmit = () => {
    if (formState.isNavigational === null) {
      showToast('Please answer: Is there a navigational result for this query?', 'error');
      return;
    }
    const currentResRating = formState.results[activeResultIndex];
    if (!currentResRating?.relevance) {
      showToast('Please select Relevance rating.', 'error');
      return;
    }

    showToast('Rating submitted successfully! Loading next available task...', 'success');
    const currentIndex = PRESET_TASKS.findIndex((p) => p.task.taskId === currentTask.taskId);
    const nextTask = PRESET_TASKS[(currentIndex + 1) % PRESET_TASKS.length].task;
    handleSelectPreset(nextTask);
  };

  const handleResetRatings = () => {
    setFormState({
      isNavigational: null,
      results: {},
    });
    setAiEvaluation(null);
    showToast('Form cleared.', 'info');
  };

  const handleConfirmRelease = (reason: string, comment: string) => {
    setIsReleaseSurveyOpen(false);
    showToast(`Survey released: ${reason}`, 'info');
    const currentIndex = PRESET_TASKS.findIndex((p) => p.task.taskId === currentTask.taskId);
    const nextTask = PRESET_TASKS[(currentIndex + 1) % PRESET_TASKS.length].task;
    handleSelectPreset(nextTask);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0A0A0B] text-slate-300 font-sans overflow-hidden select-none">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed top-16 right-6 z-50 px-4 py-2.5 rounded-xl shadow-2xl text-xs font-semibold flex items-center gap-2 border backdrop-blur-md animate-fade-in ${
            toastMessage.type === 'success'
              ? 'bg-emerald-950/90 text-emerald-200 border-emerald-500/40 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
              : toastMessage.type === 'error'
              ? 'bg-rose-950/90 text-rose-200 border-rose-500/40 shadow-[0_0_20px_rgba(244,63,94,0.3)]'
              : 'bg-slate-900/90 text-slate-200 border-white/20'
          }`}
        >
          {toastMessage.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
          {toastMessage.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400" />}
          {toastMessage.type === 'info' && <RefreshCw className="w-4 h-4 text-sky-400" />}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Top Bento Header */}
      <RatingHeader
        task={currentTask}
        onSelectPreset={handleSelectPreset}
        onOpenGuidelines={() => setIsGuidelinesOpen(true)}
        onOpenScreenshotUpload={() => setIsScreenshotUploadOpen(true)}
        onOpenAutomationScript={() => setIsAutomationScriptOpen(true)}
        onOpenReleaseSurvey={() => setIsReleaseSurveyOpen(true)}
        onAutoEvaluate={handleAutoEvaluate}
        isEvaluating={isEvaluating}
        onResetRatings={handleResetRatings}
        onSubmit={handleSubmit}
        thinkingMode={thinkingMode}
        setThinkingMode={setThinkingMode}
      />

      {/* Main Bento Grid Workspace */}
      <main className="flex-1 p-2 sm:p-3 md:p-4 grid grid-cols-1 md:grid-cols-12 gap-3 md:gap-4 overflow-hidden relative">
        {/* Bento Cell 1: Interactive Map Stage (cols 1-7) */}
        <div className="md:col-span-7 h-full flex flex-col relative rounded-2xl overflow-hidden shadow-2xl">
          <MapView
            task={currentTask}
            activeResultIndex={activeResultIndex}
            onSelectResult={(idx) => setActiveResultIndex(idx)}
          />
        </div>

        {/* Bento Cell 2: Rating Form & Rationale Engine (cols 8-12) */}
        <div className="md:col-span-5 h-full flex flex-col overflow-hidden rounded-2xl border border-white/10 shadow-2xl bg-[#0F0F11]">
          <RatingForm
            task={currentTask}
            formState={formState}
            onChangeFormState={setFormState}
            aiEvaluation={aiEvaluation}
            activeResultIndex={activeResultIndex}
            setActiveResultIndex={setActiveResultIndex}
          />
        </div>
      </main>

      {/* Bento Grid Telemetry Footer */}
      <footer className="h-9 bg-[#0F0F11] border-t border-white/5 flex items-center justify-between px-4 sm:px-6 select-none shrink-0 z-20">
        <div className="flex items-center gap-4 sm:gap-6 text-[10px] text-white/40 uppercase tracking-widest font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full shadow-[0_0_6px_#34d399]"></span>
            <span>MODEL: {thinkingMode ? 'GEMINI 3.1 PRO (HIGH THINKING)' : 'GEMINI 3.7 FLASH'}</span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5">
            <span className="w-1 h-1 bg-white/40 rounded-full"></span>
            <span>GUIDELINES: MARCH 2025</span>
          </div>
          <div className="hidden md:flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full shadow-[0_0_6px_#818cf8]"></span>
            <span className="text-indigo-400/90">TRYRATING TUNNEL: READY (ALT+A)</span>
          </div>
        </div>
        <div className="text-[10px] text-white/40 font-mono flex items-center gap-2">
          <span>TASK: <strong className="text-slate-300 font-semibold">{currentTask.taskId}</strong></span>
          <span className="text-white/20">|</span>
          <span className="text-emerald-400/80">CONFIDENCE: 98.4%</span>
        </div>
      </footer>

      {/* Modals with Bento Dark Theme */}
      <ScreenshotUploadModal
        isOpen={isScreenshotUploadOpen}
        onClose={() => setIsScreenshotUploadOpen(false)}
        onApplyParsedTask={handleApplyParsedTask}
        thinkingMode={thinkingMode}
      />

      <AutomationHelperModal
        isOpen={isAutomationScriptOpen}
        onClose={() => setIsAutomationScriptOpen(false)}
      />

      <GuidelinesHandbookModal
        isOpen={isGuidelinesOpen}
        onClose={() => setIsGuidelinesOpen(false)}
      />

      <ReleaseSurveyModal
        isOpen={isReleaseSurveyOpen}
        onClose={() => setIsReleaseSurveyOpen(false)}
        onConfirmRelease={handleConfirmRelease}
      />
    </div>
  );
}
