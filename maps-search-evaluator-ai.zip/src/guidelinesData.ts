import { GuidelineSection } from './types';

export const GUIDELINES_CHAPTERS: GuidelineSection[] = [
  {
    id: 'ch1',
    chapterNumber: '1',
    title: 'Introduction & Rating Workflow',
    summary: 'Overview of Search 2.0 evaluation goals: determining query relevance and data accuracy (name, address, pin location).',
    rules: [
      'Rate Relevance independently of data inaccuracies (name, address, pin). Always assume the result exists and is correct when evaluating relevance.',
      'For Search 2.0 projects: evaluate Relevance first, then Name and Category Accuracy, Address Accuracy, and Pin Accuracy individually.',
      'Always rate against the real world: if a better result exists in the real world but is not shown, demote the returned result.',
      'Do NOT demote duplicate results for repetition. Rate each on its own merits.',
      'Comments are MANDATORY for any Relevance rating of Good or below and for any Data issue not rated Correct/Perfect.'
    ],
    examples: [
      {
        query: '[Eiffel Tower]',
        result: 'Eiffel Tower, Paris',
        rating: 'Relevance: Navigational, Pin: Perfect',
        explanation: 'Only one result in the world completely satisfies intent.'
      }
    ]
  },
  {
    id: 'ch2',
    chapterNumber: '2',
    title: 'Understanding User Intent & Location Intent',
    summary: 'Distinguishing Explicit vs. Implicit location intent, and Fresh vs. Stale viewports.',
    rules: [
      'Explicit Location: When city/state/street is mentioned in query (e.g. [kfc Philadelphia]), ignore user and viewport location completely.',
      'Implicit Location - Fresh Viewport & User Inside: Location intent is User Location. Results inside fresh viewport cannot be rated Bad for distance alone.',
      'Implicit Location - Fresh Viewport & User Outside: Location intent is Fresh Viewport. Results in viewport receive No distance demotion (eligible for Excellent). If none in viewport, user location is secondary.',
      'Implicit Location - Stale Viewport: Location intent is User Location (whether user is inside or outside viewport). If user missing, use stale viewport.',
      'Queries with no maps intent (e.g. weather, "time in NY", facebook, definitions): Rate all results BAD (User Intent issue).'
    ],
    examples: [
      {
        query: '[bubble tea tully road san jose]',
        result: 'Tully Road, San Jose',
        rating: 'Explicit Location',
        explanation: 'User and viewport locations are ignored.'
      },
      {
        query: '[eureka temperature]',
        result: 'Weather info',
        rating: 'Bad (User Intent)',
        explanation: 'No maps intent.'
      }
    ]
  },
  {
    id: 'ch3',
    chapterNumber: '3',
    title: 'Query-Level Navigational Result Question',
    summary: 'Top-level question: "Is there a navigational result for this query?"',
    rules: [
      'Answer YES if there is in the real world a unique, single unambiguous entity that completely satisfies the distinct user intent (e.g. [Eiffel Tower], complete valid address, single-branch business, or chain + unique location modifier).',
      'Answer NO if multiple real-world entities could satisfy the query (e.g. [starbucks], category [gas station], non-existent address, coordinate query).'
    ],
    examples: [
      {
        query: '[Eiffel Tower]',
        result: 'N/A (Query level)',
        rating: 'Yes',
        explanation: 'Only one Eiffel Tower exists.'
      },
      {
        query: '[Starbucks]',
        result: 'N/A (Query level)',
        rating: 'No',
        explanation: 'Many Starbucks exist.'
      }
    ]
  },
  {
    id: 'ch4',
    chapterNumber: '4',
    title: 'Result-Level Issues: Language & Closure',
    summary: 'Handling unexpected languages/scripts and closed/non-existent businesses.',
    rules: [
      'Unexpected Language/Script in Name/Title: Checkbox stops further rating. Expected languages = test locale, query language, or result region language.',
      'Business/POI is closed or does not exist: Check checkbox, then rate relevance as if the place were OPEN (never automatically rate Bad solely for closure).',
      'Do NOT apply "Closed/Does not exist" to Address type results.'
    ],
    examples: [
      {
        query: '[market] in US (en_US)',
        result: 'ေစျးကွက် (Burmese)',
        rating: 'Unexpected Language',
        explanation: 'Burmese script is unexpected for en_US test locale.'
      }
    ]
  },
  {
    id: 'ch5',
    chapterNumber: '5',
    title: 'Relevance: Connection, Prominence & Distance',
    summary: 'Rating scale (Navigational, Excellent, Good, Acceptable, Bad) and distance/prominence tradeoffs.',
    rules: [
      'Navigational: Most likely single result completely satisfying distinct intent.',
      'Excellent: High-quality result clearly satisfying intent. Multiple results can be Excellent.',
      'Good / Acceptable / Bad: Demotions requiring [User Intent issue] or [Distance/Prominence issue] checkbox and comment.',
      'Many possible results: Demote strictly by distance (e.g. Starbucks).',
      'Few possible results: Be lenient with distance (e.g. Zara in Miami, rare street names).',
      'Rural Areas: Be generous with distance if no closer options exist.',
      'Transit Intent: Stops vs Stations (Station satisfies stop query, but Stop for station query is Bad).',
      'Parking: Free and paid parking are equally relevant. Private parking for general query is Bad.'
    ],
    examples: [
      {
        query: '[starbucks] (SF)',
        result: 'Starbucks 0.04km away',
        rating: 'Excellent',
        explanation: 'Closest location to user in fresh viewport.'
      },
      {
        query: '[starbucks] (SF)',
        result: 'Starbucks 1.5km away (outside viewport)',
        rating: 'Bad (Distance/Prominence)',
        explanation: 'Many closer locations available in area.'
      }
    ]
  },
  {
    id: 'ch6',
    chapterNumber: '6',
    title: 'Name & Category Accuracy',
    summary: 'Evaluating business/POI names, corporate suffixes, misspellings, and categories.',
    rules: [
      'Address type results: MUST ALWAYS be rated "n/a".',
      'Correct: Official name, store sign, or optional location modifier.',
      'Partially Correct: Minor/moderate misspelling (Macys vs Macy\'s), missing/extra non-critical words, ALL CAPS (GAMESTOP), corporate suffix (LLC, Inc.) not on sign, mixed expected languages.',
      'Incorrect: Severe misspelling changing meaning (Taco Bull), wrong holding company (JAB Holding for Peet\'s), slang (Mickey D\'s), wrong/misleading category (Macy\'s as Bar).',
      'If Category is Incorrect, the overall Name and Category rating is ALWAYS Incorrect.'
    ],
    examples: [
      {
        query: '[macys]',
        result: 'Macys (missing apostrophe)',
        rating: 'Partially Correct (Name Issue)',
        explanation: 'Recognizable but lacks official punctuation.'
      },
      {
        query: '[ikea]',
        result: 'IEA',
        rating: 'Incorrect (Name Issue)',
        explanation: 'Severe misspelling on short name.'
      }
    ]
  },
  {
    id: 'ch7_8',
    chapterNumber: '7 & 8',
    title: 'Address Accuracy & Result Expectations',
    summary: 'Components (Street Number, Unit, Street Name, Locality, Region, Postal Code, Country) and non-existent addresses.',
    rules: [
      'If query address does NOT exist in real world: Address Accuracy = "Incorrect - Address does not exist", Pin Accuracy = "Can\'t Verify", Relevance = "Excellent" (if matching query string).',
      'Mandatory components in US: Locality, State, Postal Code. Country mandatory if outside test locale.',
      'POIs without expected address (Parks, Stations, Landmarks): Locality is the minimum required component. Missing street address is NOT an error.',
      'Formatting issues (order, double comma, extra spacing): Rate "Correct with formatting issue" only if all required data is present and accurate.'
    ],
    examples: [
      {
        query: '[2001 Duncan St, SF]',
        result: '2001 Duncan St, SF (only goes to 1099)',
        rating: 'Incorrect - Address does not exist',
        explanation: 'Non-existent address number on street.'
      }
    ]
  },
  {
    id: 'ch9',
    chapterNumber: '9',
    title: 'Pin Accuracy & Boundary Rules',
    summary: 'Perfect, Approximate, Next Door, Wrong, and Can\'t Verify standards.',
    rules: [
      'Single Rooftop: Perfect = pin on rooftop of intended building. Approximate = on parcel/parking lot/shed. Next Door = on immediate adjacent property on same block and street (Tennis rule applies; Half \'n Half rule extends to center of street).',
      'Shared Spaces / Strip Malls: NO Next Door rating inside shared parcel. Outside parcel is Wrong.',
      'Campus / Complex: Entire parcel is Perfect. No Approximate or Next Door ratings.',
      'Underground Stations: Polygon created by station entrances. Within polygon = Perfect; within 50m = Approximate.',
      'Natural Features & Streets: Anywhere on defining feature / street is Perfect.',
      'Coordinate / "My Location": Within 50m radius = Perfect, outside 50m = Wrong.'
    ],
    examples: [
      {
        query: '[1556 Tobias Dr]',
        result: 'Pin on front driveway/yard',
        rating: 'Approximate',
        explanation: 'Within parcel boundary but off rooftop.'
      },
      {
        query: '[Stanford University]',
        result: 'Pin on campus lawn',
        rating: 'Perfect',
        explanation: 'Entire campus polygon is Perfect.'
      }
    ]
  },
  {
    id: 'ch10_11',
    chapterNumber: '10 & 11',
    title: 'Special Query Scenarios & Top Tips',
    summary: 'PERMANENT_CLOSURE handling, routing, specific address vs POI mismatches.',
    rules: [
      'Expected PERMANENT_CLOSURE (unique business or all chains closed in area): Rate as if open (Navigational/Excellent), check Business is closed.',
      'Unexpected PERMANENT_CLOSURE (category or open chains nearby): Highest rating is Acceptable or Bad (demote by 2).',
      'Query is POI name + address and result is ONLY address: Rate BAD (User Intent issue).',
      'Query is street name only and result is single business: Rate BAD (User Intent issue).',
      'Routing Queries (2 distant places, e.g. [London, Brighton]): Returning either is Excellent.'
    ],
    examples: [
      {
        query: '[Gary Danko 800 North Point St]',
        result: '800 North Point St (address only)',
        rating: 'Bad (User Intent issue)',
        explanation: 'Result misses business name from query.'
      }
    ]
  }
];
