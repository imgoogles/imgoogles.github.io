import React from 'react';
import { TaskData } from '../types';
import { Sparkles, BookOpen, UploadCloud, Code, FileText, CheckCircle2, RotateCcw, AlertTriangle, Layers } from 'lucide-react';
import { PRESET_TASKS } from '../presets';

interface RatingHeaderProps {
  task: TaskData;
  onSelectPreset: (task: TaskData) => void;
  onOpenGuidelines: () => void;
  onOpenScreenshotUpload: () => void;
  onOpenAutomationScript: () => void;
  onOpenReleaseSurvey: () => void;
  onAutoEvaluate: () => void;
  isEvaluating: boolean;
  onResetRatings: () => void;
  onSubmit: () => void;
  thinkingMode: boolean;
  setThinkingMode: (enabled: boolean) => void;
}

export const RatingHeader: React.FC<RatingHeaderProps> = ({
  task,
  onSelectPreset,
  onOpenGuidelines,
  onOpenScreenshotUpload,
  onOpenAutomationScript,
  onOpenReleaseSurvey,
  onAutoEvaluate,
  isEvaluating,
  onResetRatings,
  onSubmit,
  thinkingMode,
  setThinkingMode,
}) => {
  return (
    <header className="h-14 border-b border-white/5 flex items-center justify-between px-4 sm:px-6 bg-[#0F0F11] text-slate-300 select-none shrink-0 z-30">
      {/* Left side: Brand, Engine Status, Task Meta */}
      <div className="flex items-center gap-4 sm:gap-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-[0_0_12px_rgba(99,102,241,0.4)]">
            <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <div className="flex flex-col">
            <span className="text-xs sm:text-sm font-semibold tracking-tight text-white uppercase flex items-center gap-1.5">
              <span>Maps Eval AI</span>
              <span className="text-indigo-400 font-mono text-[10px] bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20">Pro v4.2</span>
            </span>
          </div>
        </div>

        {/* Engine status indicator */}
        <div className="hidden md:flex items-center gap-2 px-2.5 py-1 bg-white/5 rounded-full border border-white/10 text-slate-300">
          <div className={`w-2 h-2 rounded-full ${isEvaluating ? 'bg-amber-400 animate-ping' : 'bg-emerald-500 shadow-[0_0_8px_#10b981]'}`}></div>
          <span className="text-[10px] font-mono uppercase tracking-widest text-slate-300">
            {isEvaluating ? 'AI Thinking' : 'Engine: Active'}
          </span>
        </div>

        {/* Task Meta Pill */}
        <div className="hidden xl:flex items-center gap-4 text-xs font-mono text-slate-400 border-l border-white/10 pl-4">
          <div>
            <span className="text-[9px] uppercase tracking-wider text-slate-500 block font-sans">Task Type</span>
            <span className="text-slate-200 font-semibold text-[11px]">{task.taskType || 'Maps_Search_2.0'}</span>
          </div>
          <div>
            <span className="text-[9px] uppercase tracking-wider text-slate-500 block font-sans">Req ID</span>
            <span className="text-indigo-300 text-[11px]">{task.requestId || '704543232'}</span>
          </div>
          <div>
            <span className="text-[9px] uppercase tracking-wider text-slate-500 block font-sans">Est. Time</span>
            <span className="text-slate-300 text-[11px]">{task.estimatedTime || '3m 10s'}</span>
          </div>
        </div>

        {/* Preset Task Selector */}
        <div className="hidden lg:flex items-center gap-2 bg-[#141417] border border-white/10 rounded-xl px-2.5 py-1">
          <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Preset:</span>
          <select
            id="preset-task-select"
            onChange={(e) => {
              const selected = PRESET_TASKS.find((p) => p.id === e.target.value);
              if (selected) onSelectPreset(selected.task);
            }}
            className="bg-transparent text-slate-200 text-xs font-medium focus:outline-none cursor-pointer max-w-[180px] truncate"
          >
            {PRESET_TASKS.map((preset) => (
              <option key={preset.id} value={preset.id} className="bg-[#141417] text-slate-200">
                {preset.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Right side: Action Controls in Bento styling */}
      <div className="flex items-center gap-2">
        {/* Thinking Mode Toggle */}
        <button
          id="btn-toggle-thinking"
          onClick={() => setThinkingMode(!thinkingMode)}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-xs font-medium transition ${
            thinkingMode
              ? 'bg-amber-500/10 text-amber-300 border-amber-500/30 shadow-[0_0_10px_rgba(245,158,11,0.2)]'
              : 'bg-[#141417] text-slate-400 border-white/10 hover:text-slate-200 hover:border-white/20'
          }`}
          title="Toggle Gemini 3.1 Pro High Thinking Mode"
        >
          <span className="text-xs">🧠</span>
          <span className="font-mono text-[11px]">Thinking: {thinkingMode ? 'HIGH' : 'STD'}</span>
        </button>

        {/* AI Auto-Fill / Auto-Rate Button */}
        <button
          id="btn-ai-auto-rate"
          onClick={onAutoEvaluate}
          disabled={isEvaluating}
          className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-semibold px-3 py-1.5 rounded-xl shadow-[0_0_15px_rgba(99,102,241,0.4)] transition text-xs disabled:opacity-50 cursor-pointer"
          title="Execute guidelines evaluation and auto-fill answers"
        >
          <Sparkles className={`w-3.5 h-3.5 ${isEvaluating ? 'animate-spin' : ''}`} />
          <span className="uppercase tracking-wider text-[11px]">{isEvaluating ? 'Evaluating...' : 'AI Auto-Fill'}</span>
        </button>

        {/* Screenshot OCR */}
        <button
          id="btn-upload-screenshot"
          onClick={onOpenScreenshotUpload}
          className="hidden sm:flex items-center gap-1.5 bg-[#141417] hover:bg-white/10 text-slate-300 border border-white/10 px-2.5 py-1.5 rounded-xl font-medium text-xs transition"
          title="Paste screenshot (Ctrl+V) or upload image"
        >
          <UploadCloud className="w-3.5 h-3.5 text-indigo-400" />
          <span className="text-[11px]">OCR</span>
        </button>

        {/* Browser Userscript */}
        <button
          id="btn-browser-automation"
          onClick={onOpenAutomationScript}
          className="hidden sm:flex items-center gap-1.5 bg-[#141417] hover:bg-white/10 text-slate-300 border border-white/10 px-2.5 py-1.5 rounded-xl font-medium text-xs transition"
          title="Browser script for tryrating.com"
        >
          <Code className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[11px]">Script</span>
        </button>

        {/* Guidelines */}
        <button
          id="btn-open-guidelines"
          onClick={onOpenGuidelines}
          className="bg-sky-600/20 hover:bg-sky-600/30 text-sky-300 border border-sky-500/30 px-2.5 py-1.5 rounded-xl font-medium text-xs transition"
        >
          Guidelines
        </button>

        {/* Release Survey */}
        <button
          id="btn-release-survey"
          onClick={onOpenReleaseSurvey}
          className="bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 px-2.5 py-1.5 rounded-xl font-medium text-xs transition"
        >
          Release
        </button>

        {/* Submit Rating */}
        <button
          id="btn-submit-rating"
          onClick={onSubmit}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-xl shadow-[0_0_12px_rgba(16,185,129,0.3)] transition text-xs uppercase tracking-wider"
        >
          Submit
        </button>
      </div>
    </header>
  );
};
