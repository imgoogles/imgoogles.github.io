import React, { useState } from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface ReleaseSurveyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmRelease: (reason: string, comment: string) => void;
}

export const ReleaseSurveyModal: React.FC<ReleaseSurveyModalProps> = ({
  isOpen,
  onClose,
  onConfirmRelease,
}) => {
  const [selectedReason, setSelectedReason] = useState<string>('Technical Issue');
  const [comment, setComment] = useState<string>('');

  if (!isOpen) return null;

  const REASONS = [
    '1. Adult Content (Not comfortable rating adult services/strip clubs)',
    '2. Technical Issue (Map not loading, empty query, tools not interactive, >5 missing pins)',
    '3. Not Enough Time Allocated (Estimated Rating Time is insufficient)',
    '4. Other (Unforeseen blockers preventing rating)',
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#141417] text-slate-200 rounded-2xl shadow-2xl border border-white/10 w-full max-w-lg overflow-hidden animate-fade-in flex flex-col">
        <div className="bg-[#0F0F11] px-5 py-3.5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-sm">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span className="text-white uppercase tracking-wider text-xs">Release Survey</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs text-slate-300">
          <p className="text-slate-400 leading-relaxed text-[11px]">
            Please select the reason you need to skip/release this survey. If technical or other issues occurred, describe them below:
          </p>

          <div className="space-y-2">
            {REASONS.map((reason) => (
              <label
                key={reason}
                className={`flex items-center gap-2.5 p-3 rounded-xl border cursor-pointer transition ${
                  selectedReason === reason
                    ? 'border-indigo-500 bg-indigo-600/20 text-white font-semibold shadow'
                    : 'border-white/10 bg-[#0A0A0B] text-slate-300 hover:bg-white/5'
                }`}
              >
                <input
                  type="radio"
                  name="release_reason"
                  checked={selectedReason === reason}
                  onChange={() => setSelectedReason(reason)}
                  className="w-4 h-4 text-indigo-600 bg-[#0A0A0B] border-white/20"
                />
                <span className="text-xs">{reason}</span>
              </label>
            ))}
          </div>

          <div className="space-y-1.5 pt-1">
            <label className="font-semibold text-white uppercase text-[10px] tracking-wider">Comment (Required for Technical / Other issues):</label>
            <textarea
              rows={3}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="e.g. Satellite layer failed to load / Query was corrupt..."
              className="w-full bg-[#0A0A0B] border border-white/15 rounded-xl p-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 font-mono leading-relaxed"
            />
          </div>
        </div>

        <div className="bg-[#0F0F11] px-5 py-3.5 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl border border-white/10 text-slate-300 hover:bg-white/5 font-medium text-xs transition"
          >
            Cancel
          </button>
          <button
            onClick={() => onConfirmRelease(selectedReason, comment)}
            className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold shadow-[0_0_12px_rgba(244,63,94,0.4)] transition text-xs"
          >
            Confirm Release
          </button>
        </div>
      </div>
    </div>
  );
};
