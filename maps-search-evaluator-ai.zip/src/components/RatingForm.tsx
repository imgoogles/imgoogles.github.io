import React from 'react';
import {
  TaskData,
  TaskFormRatingState,
  AIEvaluationResponse,
  SingleResultRating,
  RelevanceRating,
  NameAccuracyRating,
  AddressAccuracyRating,
  PinAccuracyRating,
  AddressIssueType,
} from '../types';
import { Sparkles, Copy, Check, ExternalLink, HelpCircle, AlertTriangle, ShieldCheck, MapPin, ChevronRight, CornerDownRight } from 'lucide-react';

interface RatingFormProps {
  task: TaskData;
  formState: TaskFormRatingState;
  onChangeFormState: React.Dispatch<React.SetStateAction<TaskFormRatingState>>;
  aiEvaluation: AIEvaluationResponse | null;
  activeResultIndex: number;
  setActiveResultIndex: (idx: number) => void;
}

export const RatingForm: React.FC<RatingFormProps> = ({
  task,
  formState,
  onChangeFormState,
  aiEvaluation,
  activeResultIndex,
  setActiveResultIndex,
}) => {
  const [copiedQuery, setCopiedQuery] = React.useState(false);

  const currentResult = task.results[activeResultIndex] || task.results[0];
  const currentResultEval = aiEvaluation?.results?.find((r) => r.resultIndex === activeResultIndex);

  const currentRating: SingleResultRating = formState.results[activeResultIndex] || {
    resultIndex: activeResultIndex,
    isUnexpectedLanguage: false,
    isClosedOrNonExistent: false,
    relevance: undefined,
    userIntentIssue: false,
    distanceProminenceIssue: false,
    nameAccuracy: undefined,
    nameIssue: false,
    categoryIssue: false,
    addressAccuracy: undefined,
    addressIssues: [],
    pinAccuracy: undefined,
    pinPreciseLocationIdentified: null,
    comment: '',
  };

  const updateCurrentRating = (updates: Partial<SingleResultRating>) => {
    onChangeFormState((prev) => ({
      ...prev,
      results: {
        ...prev.results,
        [activeResultIndex]: {
          ...currentRating,
          ...updates,
        },
      },
    }));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedQuery(true);
    setTimeout(() => setCopiedQuery(false), 2000);
  };

  const isAddressType = currentResult?.type === 'ADDRESS';

  return (
    <div id="tryrating-evaluation-panel" className="h-full flex flex-col bg-[#0A0A0B] overflow-y-auto text-xs text-slate-200 select-none p-3.5 space-y-3.5">
      {/* 1. Bento Card: Query & Intent Metadata */}
      <div className="bg-[#141417] border border-white/10 rounded-2xl p-4 space-y-3 shadow-xl">
        <div className="flex items-center justify-between">
          <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">
            Query & Intent Metadata
          </span>
          <div className="flex items-center gap-1.5">
            <span className="text-[9px] font-mono text-slate-500 uppercase">March 2025 Standard</span>
            <button
              onClick={() => copyToClipboard(task.query)}
              className="text-slate-400 hover:text-white flex items-center gap-1 font-mono text-[10px] px-1.5 py-0.5 rounded bg-white/5 border border-white/10 transition"
              title="Copy Query to clipboard"
            >
              {copiedQuery ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedQuery ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* Query Display Box */}
        <div className="bg-[#0A0A0B] border border-white/10 rounded-xl p-3 flex items-start justify-between gap-2">
          <div>
            <div className="text-[10px] text-slate-500 uppercase font-mono tracking-wider mb-0.5">Target Query</div>
            <div className="text-sm font-semibold text-white font-mono select-text">{task.query}</div>
          </div>
          <span
            className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono tracking-wider ${
              task.viewportAge === 'FRESH'
                ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                : 'bg-rose-500/10 text-rose-300 border border-rose-500/20'
            }`}
          >
            VP: {task.viewportAge || 'FRESH'}
          </span>
        </div>

        {/* Metadata Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
          <div className="p-2 bg-white/5 rounded-xl border border-white/5">
            <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-mono">Locale</span>
            <span className="font-semibold text-slate-200">{task.locale || 'en_US'}</span>
          </div>
          <div className="p-2 bg-white/5 rounded-xl border border-white/5">
            <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-mono">Country</span>
            <span className="font-semibold text-slate-200 truncate block">{task.country || 'United States'}</span>
          </div>
          <div className="p-2 bg-white/5 rounded-xl border border-white/5 col-span-2">
            <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-mono">User Lat/Lng</span>
            <span className="font-semibold text-indigo-300 font-mono text-[10px] truncate block select-text">
              {task.userLat?.toFixed(6) || task.userLatLng || '39.000000'}, {task.userLng?.toFixed(6) || ''}
            </span>
          </div>
        </div>

        {/* AI Intent Breakdown if present */}
        {aiEvaluation?.queryIntent && (
          <div className="p-2.5 bg-indigo-500/5 rounded-xl border border-indigo-500/20 flex items-start gap-2">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 mt-0.5 shrink-0" />
            <div className="space-y-0.5">
              <span className="text-[10px] font-bold uppercase text-indigo-300 tracking-wider">AI Intent Analysis:</span>
              <p className="text-[11px] text-slate-300 leading-relaxed italic select-text">
                {aiEvaluation.queryIntent}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 2. Bento Card: Top Question - Navigational Result */}
      <div className="bg-[#141417] border border-white/10 rounded-2xl p-4 space-y-2.5 shadow-xl">
        <div className="flex items-center justify-between">
          <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">
            Primary Question
          </span>
          <span className="text-[10px] text-slate-500 font-mono">Chapter 5.1</span>
        </div>

        <div className="text-xs text-white font-medium">
          Is there a navigational result for this query?
        </div>

        <div className="flex items-center gap-3 pt-1">
          <label
            className={`flex-1 flex items-center justify-center gap-2 p-2.5 rounded-xl border cursor-pointer font-semibold text-xs transition ${
              formState.isNavigational === true
                ? 'bg-indigo-600 border-indigo-500 text-white shadow-[0_0_12px_rgba(99,102,241,0.3)]'
                : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
            }`}
          >
            <input
              type="radio"
              name="is_navigational"
              checked={formState.isNavigational === true}
              onChange={() => onChangeFormState((prev) => ({ ...prev, isNavigational: true }))}
              className="hidden"
            />
            <span>Yes</span>
          </label>

          <label
            className={`flex-1 flex items-center justify-center gap-2 p-2.5 rounded-xl border cursor-pointer font-semibold text-xs transition ${
              formState.isNavigational === false
                ? 'bg-indigo-600 border-indigo-500 text-white shadow-[0_0_12px_rgba(99,102,241,0.3)]'
                : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
            }`}
          >
            <input
              type="radio"
              name="is_navigational"
              checked={formState.isNavigational === false}
              onChange={() => onChangeFormState((prev) => ({ ...prev, isNavigational: false }))}
              className="hidden"
            />
            <span>No</span>
          </label>
        </div>

        {aiEvaluation?.isNavigational !== undefined && (
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5 pt-1">
            <span className="text-[10px] text-indigo-400 font-mono">Guideline rule:</span>
            <span>{aiEvaluation.navigationalReasoning || 'Identified single dominant user destination.'}</span>
          </div>
        )}
      </div>

      {/* Result Tabs (if multiple results exist) */}
      {task.results.length > 1 && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {task.results.map((res, idx) => {
            const isSelected = activeResultIndex === idx;
            return (
              <button
                key={idx}
                onClick={() => setActiveResultIndex(idx)}
                className={`px-3 py-1.5 rounded-xl font-mono text-xs font-semibold flex items-center gap-1.5 transition border ${
                  isSelected
                    ? 'bg-indigo-600 border-indigo-500 text-white shadow'
                    : 'bg-[#141417] border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                <span>Result #{idx + 1}</span>
                <span className="text-[10px] opacity-70">({res.title.slice(0, 14)})</span>
              </button>
            );
          })}
        </div>
      )}

      {/* 3. Bento Card: Result Evaluation */}
      <div className="bg-[#141417] border border-white/10 rounded-2xl p-4 space-y-4 shadow-xl">
        {/* Result Header */}
        <div className="flex items-start justify-between gap-2 border-b border-white/10 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center font-mono font-bold text-[10px]">
                {activeResultIndex + 1}
              </span>
              <h3 className="text-sm font-bold text-white select-text">{currentResult?.title}</h3>
            </div>
            <div className="text-slate-400 mt-1 select-text text-[11px] leading-relaxed">
              {currentResult?.address}
            </div>
          </div>
          <span className="bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded font-mono text-[10px]">
            {currentResult?.type || 'ADDRESS'}
          </span>
        </div>

        {/* Telemetry Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[10px] font-mono text-slate-400">
          <div className="p-2 bg-white/5 rounded-xl border border-white/5">
            <span className="text-[9px] uppercase tracking-wider text-slate-500 block">Dist to User</span>
            <span className="font-semibold text-slate-200">{currentResult?.distanceToUser || 'N/A'}</span>
          </div>
          <div className="p-2 bg-white/5 rounded-xl border border-white/5">
            <span className="text-[9px] uppercase tracking-wider text-slate-500 block">Dist to Viewport</span>
            <span className="font-semibold text-slate-200">{currentResult?.distanceToViewport || 'Inside VP'}</span>
          </div>
          <div className="p-2 bg-white/5 rounded-xl border border-white/5 col-span-2 sm:col-span-1">
            <span className="text-[9px] uppercase tracking-wider text-slate-500 block">Result Coords</span>
            <span className="font-semibold text-indigo-300 truncate block">
              {currentResult?.lat?.toFixed(4)}, {currentResult?.lng?.toFixed(4)}
            </span>
          </div>
        </div>

        {/* Flags Checkboxes */}
        <div className="space-y-2 pt-1 border-t border-white/10">
          <label className="flex items-center gap-2 cursor-pointer text-[11px] text-slate-300 hover:text-white">
            <input
              type="checkbox"
              checked={currentRating.isUnexpectedLanguage || false}
              onChange={(e) => updateCurrentRating({ isUnexpectedLanguage: e.target.checked })}
              className="w-4 h-4 rounded bg-[#0A0A0B] border-white/20 text-indigo-600 focus:ring-0"
            />
            <span>Unexpected language or script</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer text-[11px] text-slate-300 hover:text-white">
            <input
              type="checkbox"
              checked={currentRating.isClosedOrNonExistent || false}
              onChange={(e) => updateCurrentRating({ isClosedOrNonExistent: e.target.checked })}
              className="w-4 h-4 rounded bg-[#0A0A0B] border-white/20 text-indigo-600 focus:ring-0"
            />
            <span>Result is closed or does not exist</span>
          </label>
        </div>

        {/* Relevance Rating Dropdown */}
        <div className="space-y-1.5 pt-2 border-t border-white/10">
          <div className="flex items-center justify-between">
            <label className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
              <span>Relevance</span>
            </label>
            <span className="text-[10px] text-slate-500 font-mono">Chapter 5</span>
          </div>

          <select
            id="select-relevance-grade"
            value={currentRating.relevance || ''}
            onChange={(e) => updateCurrentRating({ relevance: (e.target.value || undefined) as RelevanceRating })}
            className="w-full bg-[#0A0A0B] border border-white/15 rounded-xl p-2.5 text-xs text-white font-medium focus:border-indigo-500 focus:outline-none"
          >
            <option value="" disabled className="bg-[#141417] text-slate-500">Select Relevance Grade...</option>
            <option value="Navigational" className="bg-[#141417] text-purple-300">Navigational (Single Dominant Destination)</option>
            <option value="Excellent" className="bg-[#141417] text-emerald-300">Excellent (Exact Match / Top Intent)</option>
            <option value="Good" className="bg-[#141417] text-sky-300">Good (Reasonable / Alternate Location)</option>
            <option value="Acceptable" className="bg-[#141417] text-amber-300">Acceptable (Distant / Partial Fit)</option>
            <option value="Bad" className="bg-[#141417] text-rose-300">Bad (Irrelevant / Wrong Category)</option>
          </select>

          {/* Relevance Demotions check */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <label className="flex items-center gap-1.5 text-[10px] text-slate-400 cursor-pointer">
              <input
                type="checkbox"
                checked={currentRating.userIntentIssue || false}
                onChange={(e) => updateCurrentRating({ userIntentIssue: e.target.checked })}
                className="w-3.5 h-3.5 rounded bg-[#0A0A0B] border-white/20 text-indigo-600"
              />
              <span>User Intent Issue</span>
            </label>
            <label className="flex items-center gap-1.5 text-[10px] text-slate-400 cursor-pointer">
              <input
                type="checkbox"
                checked={currentRating.distanceProminenceIssue || false}
                onChange={(e) => updateCurrentRating({ distanceProminenceIssue: e.target.checked })}
                className="w-3.5 h-3.5 rounded bg-[#0A0A0B] border-white/20 text-indigo-600"
              />
              <span>Distance / Prominence Issue</span>
            </label>
          </div>
        </div>

        {/* Name and Category Accuracy */}
        <div className="space-y-1.5 pt-2 border-t border-white/10">
          <div className="flex items-center justify-between">
            <label className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
              <span>Name and Category Accuracy</span>
            </label>
            <span className="text-[10px] text-slate-500 font-mono">Chapter 6</span>
          </div>

          <select
            id="select-name-category-grade"
            value={currentRating.nameAccuracy || (isAddressType ? 'n/a' : '')}
            onChange={(e) => updateCurrentRating({ nameAccuracy: e.target.value as NameAccuracyRating })}
            className="w-full bg-[#0A0A0B] border border-white/15 rounded-xl p-2.5 text-xs text-white font-medium focus:border-indigo-500 focus:outline-none"
          >
            <option value="" disabled className="bg-[#141417] text-slate-500">Select Accuracy Grade...</option>
            <option value="n/a" className="bg-[#141417] text-slate-400">n/a (Standard Address - No Name/Category)</option>
            <option value="Correct" className="bg-[#141417] text-emerald-300">Correct</option>
            <option value="Partially Correct" className="bg-[#141417] text-amber-300">Partially Correct (Minor Alias / Secondary Subtype)</option>
            <option value="Incorrect" className="bg-[#141417] text-rose-300">Incorrect</option>
            <option value="Can't Verify" className="bg-[#141417] text-slate-400">Can't Verify</option>
          </select>
        </div>

        {/* Address Accuracy */}
        <div className="space-y-1.5 pt-2 border-t border-white/10">
          <div className="flex items-center justify-between">
            <label className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
              <span>Address Accuracy</span>
            </label>
            <span className="text-[10px] text-slate-500 font-mono">Chapter 7</span>
          </div>

          <select
            id="select-address-grade"
            value={currentRating.addressAccuracy || ''}
            onChange={(e) => updateCurrentRating({ addressAccuracy: e.target.value as AddressAccuracyRating })}
            className="w-full bg-[#0A0A0B] border border-white/15 rounded-xl p-2.5 text-xs text-white font-medium focus:border-indigo-500 focus:outline-none"
          >
            <option value="" disabled className="bg-[#141417] text-slate-500">Select Address Accuracy...</option>
            <option value="Correct" className="bg-[#141417] text-emerald-300">Correct (All components present and valid)</option>
            <option value="Correct with formatting issue" className="bg-[#141417] text-amber-300">Correct with formatting issue (Spelling/Punctuation)</option>
            <option value="Incorrect" className="bg-[#141417] text-rose-300">Incorrect (Wrong street/number/locality)</option>
            <option value="Can't Verify" className="bg-[#141417] text-slate-400">Can't Verify</option>
          </select>

          {/* If Incorrect, show component checkboxes */}
          {currentRating.addressAccuracy === 'Incorrect' && (
            <div className="p-2.5 bg-rose-500/10 border border-rose-500/20 rounded-xl space-y-1.5 text-[10px]">
              <span className="font-semibold text-rose-300 block">Select incorrect components:</span>
              <div className="grid grid-cols-2 gap-1.5">
                {(['Street Number', 'Street Name', 'Locality', 'Postal Code', 'Region/State', 'Country'] as AddressIssueType[]).map((comp) => {
                  const isChecked = currentRating.addressIssues?.includes(comp);
                  return (
                    <label key={comp} className="flex items-center gap-1.5 cursor-pointer text-slate-300">
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => {
                          const existing = currentRating.addressIssues || [];
                          const next = e.target.checked ? [...existing, comp] : existing.filter((c) => c !== comp);
                          updateCurrentRating({ addressIssues: next });
                        }}
                        className="w-3.5 h-3.5 rounded bg-[#0A0A0B] border-white/20 text-rose-600"
                      />
                      <span>{comp}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Pin Accuracy */}
        <div className="space-y-1.5 pt-2 border-t border-white/10">
          <div className="flex items-center justify-between">
            <label className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
              <span>Pin Accuracy</span>
            </label>
            <span className="text-[10px] text-slate-500 font-mono">Chapter 8</span>
          </div>

          <select
            id="select-pin-grade"
            value={currentRating.pinAccuracy || ''}
            onChange={(e) => updateCurrentRating({ pinAccuracy: e.target.value as PinAccuracyRating })}
            className="w-full bg-[#0A0A0B] border border-white/15 rounded-xl p-2.5 text-xs text-white font-medium focus:border-indigo-500 focus:outline-none"
          >
            <option value="" disabled className="bg-[#141417] text-slate-500">Select Pin Accuracy...</option>
            <option value="Perfect" className="bg-[#141417] text-emerald-300">Perfect (Rooftop / Center of parcel)</option>
            <option value="Approximate" className="bg-[#141417] text-sky-300">Approximate (Nearby on parcel / Street entry)</option>
            <option value="Next Door" className="bg-[#141417] text-amber-300">Next Door (Adjacent building / within 50m)</option>
            <option value="Wrong" className="bg-[#141417] text-rose-300">Wrong (&gt;50m away / Incorrect parcel)</option>
            <option value="Can't Verify" className="bg-[#141417] text-slate-400">Can't Verify</option>
          </select>

          {/* Question: Was the precise location of the result identified? */}
          <div className="p-2.5 bg-white/5 rounded-xl border border-white/10 space-y-1.5">
            <span className="text-[11px] text-slate-300 block font-medium">
              Was the precise location of the result identified?
            </span>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-slate-300 hover:text-white">
                <input
                  type="radio"
                  name="pin_precise_identified"
                  checked={currentRating.pinPreciseLocationIdentified === true}
                  onChange={() => updateCurrentRating({ pinPreciseLocationIdentified: true })}
                  className="text-indigo-600 bg-[#0A0A0B] border-white/20"
                />
                <span>Yes</span>
              </label>
              <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-slate-300 hover:text-white">
                <input
                  type="radio"
                  name="pin_precise_identified"
                  checked={currentRating.pinPreciseLocationIdentified === false}
                  onChange={() => updateCurrentRating({ pinPreciseLocationIdentified: false })}
                  className="text-indigo-600 bg-[#0A0A0B] border-white/20"
                />
                <span>No</span>
              </label>
            </div>
          </div>
        </div>

        {/* Comment and Guidelines Reference */}
        <div className="space-y-1.5 pt-2 border-t border-white/10">
          <div className="flex items-center justify-between">
            <label className="font-bold text-white text-xs uppercase tracking-wider">Comment & Evidence Source</label>
            <span className="text-[10px] text-slate-500 font-mono">English only</span>
          </div>

          <textarea
            id="textarea-rating-comment"
            rows={3}
            value={currentRating.comment || ''}
            onChange={(e) => updateCurrentRating({ comment: e.target.value })}
            placeholder="Official rationale in English citing guideline section..."
            className="w-full bg-[#0A0A0B] border border-white/15 rounded-xl p-2.5 text-xs text-white font-mono leading-relaxed focus:border-indigo-500 focus:outline-none select-text"
          />

          <button
            onClick={() => copyToClipboard(currentRating.comment || '')}
            className="w-full py-1.5 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl border border-white/10 font-mono text-[10px] flex items-center justify-center gap-1.5 transition"
          >
            <Copy className="w-3 h-3 text-indigo-400" />
            <span>Copy Comment for TryRating</span>
          </button>
        </div>

        {/* AI Suggestion / Guideline Reference Bento Box */}
        {currentResultEval && (
          <div className="p-3 bg-amber-400/5 border border-amber-400/20 rounded-xl space-y-1 text-[11px] text-amber-200/90">
            <div className="font-bold text-[10px] uppercase tracking-wider text-amber-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              <span>AI Rule Rationale ({currentResultEval.guidelineSection || 'Guidelines'})</span>
            </div>
            <p className="leading-relaxed italic select-text">
              "{currentResultEval.suggestedComment}"
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
