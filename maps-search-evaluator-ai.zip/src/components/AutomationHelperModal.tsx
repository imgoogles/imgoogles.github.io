import React, { useState } from 'react';
import { Code, Copy, Check, ExternalLink, ShieldCheck, Zap, X } from 'lucide-react';

interface AutomationHelperModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AutomationHelperModal: React.FC<AutomationHelperModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [scriptType, setScriptType] = useState<'tampermonkey' | 'bookmarklet' | 'console'>('tampermonkey');

  if (!isOpen) return null;

  const currentHost = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000';

  const tampermonkeyScript = `// ==UserScript==
// @name         TryRating Auto-Evaluator (March 2025 Guidelines)
// @namespace    http://tampermonkey.net/
// @version      2.0.0
// @description  Automated evaluation and 1-click filling on TryRating based on March 2025 Maps Search Guidelines
// @author       Evaluator Assistant
// @match        https://www.tryrating.com/app/survey/rate*
// @match        https://tryrating.com/app/survey/rate*
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// ==/UserScript==

(function() {
  'use strict';

  console.log('⚡ TryRating Auto-Evaluator loaded.');

  // Create Floating Action Bar on TryRating page
  const floatingBar = document.createElement('div');
  floatingBar.id = 'tryrating-ai-assistant-bar';
  floatingBar.style.position = 'fixed';
  floatingBar.style.bottom = '20px';
  floatingBar.style.right = '20px';
  floatingBar.style.zIndex = '999999';
  floatingBar.style.backgroundColor = '#141417';
  floatingBar.style.border = '1px solid rgba(255, 255, 255, 0.15)';
  floatingBar.style.color = '#ffffff';
  floatingBar.style.padding = '12px 16px';
  floatingBar.style.borderRadius = '16px';
  floatingBar.style.boxShadow = '0 20px 30px -5px rgba(0, 0, 0, 0.8)';
  floatingBar.style.fontFamily = 'system-ui, sans-serif';
  floatingBar.style.fontSize = '12px';
  floatingBar.style.display = 'flex';
  floatingBar.style.alignItems = 'center';
  floatingBar.style.gap = '10px';

  floatingBar.innerHTML = \`
    <div style="font-weight: bold; color: #818cf8; display: flex; items-center; gap: 4px;">
      ✨ Maps 2.0 AI Rater
    </div>
    <button id="btn-auto-evaluate-page" style="background: #4f46e5; color: white; border: none; padding: 6px 12px; border-radius: 10px; font-weight: bold; cursor: pointer; font-size: 11px; box-shadow: 0 0 10px rgba(99,102,241,0.5);">
      ⚡ Auto-Rate (Alt+A)
    </button>
    <button id="btn-open-workbench" style="background: rgba(255,255,255,0.1); color: #e2e8f0; border: 1px solid rgba(255,255,255,0.1); padding: 6px 10px; border-radius: 10px; cursor: pointer; font-size: 11px;">
      Open Workbench
    </button>
  \`;

  document.body.appendChild(floatingBar);

  document.getElementById('btn-open-workbench').addEventListener('click', () => {
    window.open('${currentHost}', '_blank');
  });

  function extractTaskFromPage() {
    const queryEl = document.querySelector('[data-testid="query-text"], .query-text, .query-field');
    const query = queryEl ? queryEl.innerText.trim() : document.body.innerText.match(/Query\\s*[:\\t]\\s*(.+)/i)?.[1]?.trim() || '';

    const viewportAge = document.body.innerText.includes('STALE') ? 'STALE' : 'FRESH';
    const localeMatch = document.body.innerText.match(/Locale\\s*[:\\t]\\s*([a-zA-Z_]+)/i);
    const locale = localeMatch ? localeMatch[1] : 'en_US';

    const coordsMatch = document.body.innerText.match(/User Lat,?\\s*Lng\\s*[:\\t]\\s*([\\d.-]+,\\s*[\\d.-]+)/i);
    const userLatLng = coordsMatch ? coordsMatch[1] : '';

    return {
      query,
      viewportAge,
      locale,
      country: 'United States',
      userLatLng,
      taskType: 'Maps_Search_2.0',
      results: [{
        id: 'res-1',
        resultNumber: 1,
        title: query,
        address: document.querySelector('.result-address, [data-testid="result-address"]')?.innerText || '',
        type: 'ADDRESS'
      }]
    };
  }

  async function performAutoRate() {
    const btn = document.getElementById('btn-auto-evaluate-page');
    btn.innerText = 'Evaluating...';
    btn.disabled = true;

    try {
      const task = extractTaskFromPage();
      const response = await fetch('${currentHost}/api/evaluate-task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task, useThinking: false })
      });
      const data = await response.json();

      if (data.success && data.evaluation) {
        const evalData = data.evaluation;

        if (evalData.isNavigational !== null) {
          const yesRadio = document.querySelector('input[type="radio"][value="true"], input[type="radio"][id*="yes" i]');
          const noRadio = document.querySelector('input[type="radio"][value="false"], input[type="radio"][id*="no" i]');
          if (evalData.isNavigational && yesRadio) { yesRadio.click(); }
          else if (!evalData.isNavigational && noRadio) { noRadio.click(); }
        }

        const resEval = evalData.results[0];
        if (resEval) {
          const relevanceSelect = document.querySelector('select[name*="relevance" i], select[id*="relevance" i]');
          if (relevanceSelect && resEval.relevance) {
            relevanceSelect.value = resEval.relevance;
            relevanceSelect.dispatchEvent(new Event('change', { bubbles: true }));
          }

          const nameSelect = document.querySelector('select[name*="name" i], select[id*="name" i]');
          if (nameSelect && resEval.nameAccuracy) {
            nameSelect.value = resEval.nameAccuracy;
            nameSelect.dispatchEvent(new Event('change', { bubbles: true }));
          }

          const addrSelect = document.querySelector('select[name*="address" i], select[id*="address" i]');
          if (addrSelect && resEval.addressAccuracy) {
            addrSelect.value = resEval.addressAccuracy;
            addrSelect.dispatchEvent(new Event('change', { bubbles: true }));
          }

          const pinSelect = document.querySelector('select[name*="pin" i], select[id*="pin" i]');
          if (pinSelect && resEval.pinAccuracy) {
            pinSelect.value = resEval.pinAccuracy;
            pinSelect.dispatchEvent(new Event('change', { bubbles: true }));
          }

          const commentBox = document.querySelector('textarea, [name*="comment" i]');
          if (commentBox && resEval.suggestedComment) {
            commentBox.value = resEval.suggestedComment;
            commentBox.dispatchEvent(new Event('input', { bubbles: true }));
          }
        }

        btn.innerText = '✅ Form Filled!';
        setTimeout(() => { btn.innerText = '⚡ Auto-Rate (Alt+A)'; btn.disabled = false; }, 3000);
      }
    } catch (e) {
      console.error(e);
      btn.innerText = '⚠️ Error - Check Workbench';
      setTimeout(() => { btn.innerText = '⚡ Auto-Rate (Alt+A)'; btn.disabled = false; }, 3000);
    }
  }

  document.getElementById('btn-auto-evaluate-page').addEventListener('click', performAutoRate);

  window.addEventListener('keydown', (e) => {
    if (e.altKey && (e.key === 'a' || e.key === 'A')) {
      performAutoRate();
    }
  });
})();
`;

  const bookmarkletCode = `javascript:(function(){window.open('${currentHost}','_blank');})();`;

  const copyScript = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#141417] text-slate-200 rounded-2xl shadow-2xl border border-white/10 w-full max-w-3xl overflow-hidden animate-fade-in flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-[#0F0F11] px-5 py-3.5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-sm">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span className="text-white uppercase tracking-wider text-xs">TryRating Browser Auto-Filler & Automation Script</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs text-slate-300">
          <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl space-y-1">
            <div className="font-semibold flex items-center gap-1.5 text-emerald-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Direct Screen Auto-Fill on TryRating</span>
            </div>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              You can run this app side-by-side OR install this Tampermonkey userscript. When you are on{' '}
              <code className="bg-[#0A0A0B] px-1.5 py-0.5 rounded border border-emerald-500/30 text-emerald-300 font-mono">tryrating.com/app/survey/rate</code>,
              pressing <kbd className="bg-white/10 px-1.5 py-0.5 rounded font-mono font-bold border border-white/20 text-white">Alt + A</kbd>{' '}
              will automatically extract the task, query the March 2025 guideline AI engine, and click all checkboxes, dropdowns, and comment boxes directly on your screen!
            </p>
          </div>

          {/* Selector Tabs */}
          <div className="flex items-center gap-2 border-b border-white/10 pb-2">
            <button
              onClick={() => setScriptType('tampermonkey')}
              className={`px-3 py-1.5 rounded-xl font-medium transition text-xs ${
                scriptType === 'tampermonkey' ? 'bg-indigo-600 text-white shadow' : 'bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              Tampermonkey Userscript (.user.js)
            </button>
            <button
              onClick={() => setScriptType('console')}
              className={`px-3 py-1.5 rounded-xl font-medium transition text-xs ${
                scriptType === 'console' ? 'bg-indigo-600 text-white shadow' : 'bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              DevTools Console Snippet
            </button>
            <button
              onClick={() => setScriptType('bookmarklet')}
              className={`px-3 py-1.5 rounded-xl font-medium transition text-xs ${
                scriptType === 'bookmarklet' ? 'bg-indigo-600 text-white shadow' : 'bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              Bookmarklet (1-Click)
            </button>
          </div>

          {/* Quick Steps */}
          <div className="space-y-1">
            <h4 className="font-semibold text-white uppercase text-[11px] tracking-wider">How to install in 3 steps:</h4>
            <ol className="list-decimal list-inside space-y-1 text-slate-400 pl-1 text-[11px]">
              <li>Install <strong>Tampermonkey</strong> or <strong>Violentmonkey</strong> extension in Chrome/Edge/Firefox.</li>
              <li>Create a new script, copy and paste the code below, and press <strong>Save (Ctrl+S)</strong>.</li>
              <li>Open your TryRating survey tab and use the purple floating button or press <kbd className="font-mono bg-white/10 px-1 border border-white/20 rounded text-white">Alt+A</kbd>!</li>
            </ol>
          </div>

          {/* Code Viewer */}
          <div className="relative">
            <pre className="bg-[#0A0A0B] text-emerald-400 p-3.5 rounded-xl border border-white/10 font-mono text-[11px] max-h-64 overflow-x-auto overflow-y-auto leading-tight select-all">
              {scriptType === 'tampermonkey' && tampermonkeyScript}
              {scriptType === 'console' && tampermonkeyScript}
              {scriptType === 'bookmarklet' && bookmarkletCode}
            </pre>
            <button
              onClick={() => copyScript(scriptType === 'bookmarklet' ? bookmarkletCode : tampermonkeyScript)}
              className="absolute top-2 right-2 bg-[#141417] hover:bg-white/10 text-white border border-white/20 px-2.5 py-1 rounded-lg flex items-center gap-1 font-medium text-[11px] shadow transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Code'}</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#0F0F11] px-5 py-3 border-t border-white/10 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-500">Works with Google Chrome, Microsoft Edge, Firefox, Brave, Safari</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl font-medium text-xs transition border border-white/10"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
