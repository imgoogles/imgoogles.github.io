import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { TaskData, TaskResult } from '../types';
import { Layers, Ruler, MapPin, Crosshair, ZoomIn, ZoomOut } from 'lucide-react';

interface MapViewProps {
  task: TaskData;
  activeResultIndex?: number;
  onSelectResult?: (index: number) => void;
}

type MapLayerType = 'Standard' | 'Satellite' | 'Hybrid';

export const MapView: React.FC<MapViewProps> = ({
  task,
  activeResultIndex = 0,
  onSelectResult,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  const [currentLayer, setCurrentLayer] = useState<MapLayerType>('Standard');
  const [measuringMode, setMeasuringMode] = useState<boolean>(false);
  const [measurePoints, setMeasurePoints] = useState<L.LatLng[]>([]);
  const [measureDistanceText, setMeasureDistanceText] = useState<string | null>(null);
  const [droppedPin, setDroppedPin] = useState<{ lat: number; lng: number } | null>(null);
  const [dropPinActive, setDropPinActive] = useState<boolean>(false);
  const [show50mCircle, setShow50mCircle] = useState<boolean>(true);
  const [mouseCoords, setMouseCoords] = useState<{ lat: string; lng: string; zoom: number }>({
    lat: '0.000000',
    lng: '0.000000',
    zoom: 8,
  });

  const getTileUrl = (type: MapLayerType) => {
    switch (type) {
      case 'Satellite':
        return 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
      case 'Hybrid':
        return 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
      case 'Standard':
      default:
        return 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
    }
  };

  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const initialLat = task.results[0]?.lat || task.userLat || 39.0;
    const initialLng = task.results[0]?.lng || task.userLng || -94.0;

    const map = L.map(mapContainerRef.current, {
      center: [initialLat, initialLng],
      zoom: 7,
      zoomControl: false,
    });

    const tileLayer = L.tileLayer(getTileUrl('Standard'), {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap &copy; CARTO &copy; Esri',
      subdomains: 'abcd',
    }).addTo(map);

    tileLayerRef.current = tileLayer;
    layerGroupRef.current = L.layerGroup().addTo(map);
    mapInstanceRef.current = map;

    map.on('mousemove', (e: L.LeafletMouseEvent) => {
      setMouseCoords({
        lat: e.latlng.lat.toFixed(6),
        lng: e.latlng.lng.toFixed(6),
        zoom: map.getZoom(),
      });
    });

    map.on('click', (e: L.LeafletMouseEvent) => {
      if (measuringMode) {
        setMeasurePoints((prev) => {
          const next = [...prev, e.latlng];
          if (next.length === 2) {
            const distMeters = next[0].distanceTo(next[1]);
            const distStr = distMeters > 1000 ? `${(distMeters / 1000).toFixed(2)} km` : `${distMeters.toFixed(1)} m`;
            setMeasureDistanceText(distStr);
          } else if (next.length > 2) {
            return [e.latlng];
          }
          return next;
        });
      } else if (dropPinActive) {
        setDroppedPin({ lat: e.latlng.lat, lng: e.latlng.lng });
        setDropPinActive(false);
      }
    });

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!tileLayerRef.current || !mapInstanceRef.current) return;
    tileLayerRef.current.setUrl(getTileUrl(currentLayer));
  }, [currentLayer]);

  useEffect(() => {
    if (!mapInstanceRef.current || !layerGroupRef.current) return;
    const lg = layerGroupRef.current;
    lg.clearLayers();

    const bounds = L.latLngBounds([]);

    // 1. Draw User Marker
    if (task.userLat && task.userLng) {
      const userLatLng = L.latLng(task.userLat, task.userLng);
      bounds.extend(userLatLng);

      const userHtml = `
        <div class="flex flex-col items-center group cursor-pointer">
          <div class="w-8 h-8 bg-blue-600 rounded-full border-2 border-white shadow-[0_0_10px_rgba(37,99,235,0.8)] flex items-center justify-center text-white">
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
          </div>
          <span class="bg-blue-800 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow mt-0.5 font-mono whitespace-nowrap">User</span>
        </div>
      `;

      const userMarker = L.marker(userLatLng, {
        icon: L.divIcon({
          html: userHtml,
          className: 'tryrating-user-marker',
          iconSize: [40, 48],
          iconAnchor: [20, 24],
        }),
      }).addTo(lg);

      userMarker.bindPopup(`
        <div class="text-xs p-1 text-slate-200">
          <div class="font-bold text-sky-400">User Position</div>
          <div class="font-mono text-[11px]">${task.userLat.toFixed(6)}, ${task.userLng.toFixed(6)}</div>
          <div class="text-slate-400 mt-1 text-[10px]">Locale: ${task.locale} (${task.country})</div>
        </div>
      `);

      if (show50mCircle) {
        L.circle(userLatLng, {
          radius: 50,
          color: '#3b82f6',
          weight: 1.5,
          fillColor: '#3b82f6',
          fillOpacity: 0.15,
          dashArray: '4, 4',
        }).addTo(lg);
      }
    }

    // 2. Viewport Box
    const vpLat = task.viewportCenterLat || task.userLat || 39.0;
    const vpLng = task.viewportCenterLng || task.userLng || -94.0;
    const vpRadius = (task.viewportRadiusKm || 40) / 111;

    const vpBounds = L.latLngBounds(
      [vpLat - vpRadius * 0.7, vpLng - vpRadius],
      [vpLat + vpRadius * 0.7, vpLng + vpRadius]
    );

    const isFresh = task.viewportAge === 'FRESH';
    const vpColor = isFresh ? '#a855f7' : '#94a3b8';

    L.rectangle(vpBounds, {
      color: vpColor,
      weight: 2,
      fillColor: vpColor,
      fillOpacity: 0.08,
      dashArray: isFresh ? undefined : '5, 5',
    }).addTo(lg);

    const vpCenter = vpBounds.getCenter();
    const deviceHtml = `
      <div class="w-7 h-10 bg-[#141417] border-2 border-indigo-400/80 rounded-md shadow-lg flex flex-col items-center justify-between p-0.5 opacity-90">
        <div class="w-2 h-0.5 bg-slate-500 rounded"></div>
        <div class="w-5 h-6 ${isFresh ? 'bg-purple-950/60' : 'bg-slate-800'} rounded-sm flex items-center justify-center">
          <span class="text-[8px] font-bold font-mono ${isFresh ? 'text-purple-300' : 'text-slate-400'}">VP</span>
        </div>
        <div class="w-1.5 h-1.5 rounded-full bg-slate-500"></div>
      </div>
    `;

    L.marker(vpCenter, {
      icon: L.divIcon({
        html: deviceHtml,
        iconSize: [28, 40],
        iconAnchor: [14, 20],
      }),
    }).addTo(lg);

    // 3. Result Pins
    const pinColors = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#6366f1'];

    task.results.forEach((res, idx) => {
      if (res.lat && res.lng) {
        const pinLatLng = L.latLng(res.lat, res.lng);
        bounds.extend(pinLatLng);

        const color = pinColors[idx % pinColors.length];
        const isSelected = activeResultIndex === idx;

        const pinHtml = `
          <div class="relative group cursor-pointer transition-transform duration-150 ${isSelected ? 'scale-125 z-50' : 'hover:scale-110'}">
            <div class="w-8 h-8 rounded-full border-2 border-white shadow-[0_0_12px_rgba(0,0,0,0.6)] flex items-center justify-center text-white text-xs font-black font-mono" style="background-color: ${color}">
              ${idx + 1}
            </div>
            <div class="w-2 h-2 rotate-45 border-r-2 border-b-2 border-white absolute -bottom-1 left-3" style="background-color: ${color}"></div>
          </div>
        `;

        const pinMarker = L.marker(pinLatLng, {
          icon: L.divIcon({
            html: pinHtml,
            iconSize: [32, 40],
            iconAnchor: [16, 36],
          }),
        }).addTo(lg);

        pinMarker.on('click', () => {
          if (onSelectResult) onSelectResult(idx);
        });

        pinMarker.bindPopup(`
          <div class="text-xs p-1.5 min-w-[210px] text-slate-200">
            <div class="flex items-center gap-1.5 mb-1.5">
              <span class="w-4 h-4 rounded-full text-white flex items-center justify-center text-[10px] font-bold" style="background-color: ${color}">${idx + 1}</span>
              <strong class="text-white text-sm font-semibold">${res.title}</strong>
            </div>
            <div class="text-slate-300 whitespace-pre-line text-[11px] mb-2 leading-relaxed">${res.address}</div>
            <div class="border-t border-white/10 pt-1.5 text-[10px] text-slate-400 space-y-1">
              <div>Type: <span class="font-medium text-indigo-300">${res.type || 'N/A'}</span></div>
              ${res.distanceToUser ? `<div>Dist to User: <span class="font-mono text-slate-200">${res.distanceToUser}</span></div>` : ''}
              ${res.distanceToViewport ? `<div>Dist to Viewport: <span class="font-mono text-slate-200">${res.distanceToViewport}</span></div>` : ''}
              <div>Coords: <span class="font-mono text-slate-400">${res.lat.toFixed(6)}, ${res.lng.toFixed(6)}</span></div>
            </div>
          </div>
        `);

        if (show50mCircle) {
          L.circle(pinLatLng, {
            radius: 50,
            color: color,
            weight: 1,
            fillColor: color,
            fillOpacity: 0.1,
          }).addTo(lg);
        }
      }
    });

    if (measurePoints.length > 0) {
      measurePoints.forEach((pt, i) => {
        L.circleMarker(pt, {
          radius: 6,
          color: i === 0 ? '#10b981' : '#ef4444',
          fillColor: i === 0 ? '#10b981' : '#ef4444',
          fillOpacity: 1,
        }).addTo(lg);
      });

      if (measurePoints.length >= 2) {
        L.polyline(measurePoints, {
          color: '#ef4444',
          weight: 3,
          dashArray: '6, 6',
        }).addTo(lg);
      }
    }

    if (droppedPin) {
      const dropLatLng = L.latLng(droppedPin.lat, droppedPin.lng);
      const dropHtml = `
        <div class="w-6 h-6 bg-purple-600 rounded-full border-2 border-white shadow-lg flex items-center justify-center text-white text-[10px] font-bold animate-bounce">
          📍
        </div>
      `;
      L.marker(dropLatLng, {
        icon: L.divIcon({ html: dropHtml, iconSize: [24, 24], iconAnchor: [12, 24] }),
      })
        .addTo(lg)
        .bindPopup(`
          <div class="text-xs text-slate-200">
            <strong class="text-purple-300">Custom Dropped Pin</strong>
            <div class="font-mono">${droppedPin.lat.toFixed(6)}, ${droppedPin.lng.toFixed(6)}</div>
          </div>
        `)
        .openPopup();
    }

    if (bounds.isValid()) {
      mapInstanceRef.current.fitBounds(bounds.pad(0.3));
    }
  }, [task, activeResultIndex, show50mCircle, measurePoints, droppedPin]);

  const handleShowUser = () => {
    if (!mapInstanceRef.current || !task.userLat || !task.userLng) return;
    mapInstanceRef.current.panTo([task.userLat, task.userLng]);
  };

  const handleShowViewport = () => {
    if (!mapInstanceRef.current) return;
    const vpLat = task.viewportCenterLat || task.userLat || 39.0;
    const vpLng = task.viewportCenterLng || task.userLng || -94.0;
    mapInstanceRef.current.setView([vpLat, vpLng], 12);
  };

  const handleShowAll = () => {
    if (!mapInstanceRef.current) return;
    const bounds = L.latLngBounds([]);
    if (task.userLat && task.userLng) bounds.extend([task.userLat, task.userLng]);
    task.results.forEach((r) => {
      if (r.lat && r.lng) bounds.extend([r.lat, r.lng]);
    });
    if (bounds.isValid()) {
      mapInstanceRef.current.fitBounds(bounds.pad(0.3));
    }
  };

  return (
    <div id="tryrating-map-container" className="relative w-full h-full flex flex-col bg-[#0A0A0B] rounded-2xl overflow-hidden border border-white/10 select-none shadow-2xl">
      {/* Top Viewport Shortcut Bar */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1 bg-[#141417]/90 backdrop-blur-md shadow-xl px-2 py-1 rounded-xl border border-white/10 text-xs font-medium text-slate-300">
        <button
          id="btn-show-viewport"
          onClick={handleShowViewport}
          className="px-2.5 py-1 rounded-lg hover:bg-white/10 active:bg-white/20 text-indigo-300 font-semibold transition"
          title="Pan to viewport center"
        >
          Show Viewport
        </button>
        <div className="w-[1px] h-3.5 bg-white/10"></div>
        <button
          id="btn-show-user"
          onClick={handleShowUser}
          className="px-2.5 py-1 rounded-lg hover:bg-white/10 active:bg-white/20 text-indigo-300 font-semibold transition"
          title="Pan to user position"
        >
          Show User
        </button>
        <div className="w-[1px] h-3.5 bg-white/10"></div>
        <button
          id="btn-show-all"
          onClick={handleShowAll}
          className="px-2.5 py-1 rounded-lg hover:bg-white/10 active:bg-white/20 text-indigo-300 font-semibold transition"
          title="Fit all pins in view"
        >
          Show All
        </button>
      </div>

      {/* Top-Left Layer Selector */}
      <div className="absolute top-3 left-3 z-20 flex items-center bg-[#141417]/90 backdrop-blur-md shadow-xl rounded-xl border border-white/10 text-xs text-slate-300">
        <div className="flex items-center gap-1.5 px-2.5 py-1.5 border-r border-white/10 text-slate-400 font-semibold">
          <Layers className="w-3.5 h-3.5 text-indigo-400" />
          <span className="text-[10px] uppercase tracking-wider">Layer</span>
        </div>
        <select
          id="map-layer-selector"
          value={currentLayer}
          onChange={(e) => setCurrentLayer(e.target.value as MapLayerType)}
          className="bg-transparent px-2.5 py-1.5 font-semibold text-slate-200 focus:outline-none cursor-pointer"
        >
          <option value="Standard" className="bg-[#141417]">Standard</option>
          <option value="Satellite" className="bg-[#141417]">Satellite</option>
          <option value="Hybrid" className="bg-[#141417]">Hybrid</option>
        </select>
      </div>

      {/* Top-Right Tools */}
      <div className="absolute top-3 right-3 z-20 flex items-center gap-1 bg-[#141417]/90 backdrop-blur-md shadow-xl px-1.5 py-1 rounded-xl border border-white/10 text-xs">
        <button
          id="btn-drop-pin"
          onClick={() => {
            setDropPinActive(!dropPinActive);
            setMeasuringMode(false);
          }}
          className={`p-1.5 rounded-lg transition ${dropPinActive ? 'bg-purple-600 text-white' : 'text-slate-300 hover:bg-white/10'}`}
          title="Click map to drop custom pin"
        >
          <MapPin className="w-4 h-4" />
        </button>
        <button
          id="btn-ruler-measure"
          onClick={() => {
            setMeasuringMode(!measuringMode);
            setDropPinActive(false);
            setMeasurePoints([]);
            setMeasureDistanceText(null);
          }}
          className={`p-1.5 rounded-lg transition ${measuringMode ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-white/10'}`}
          title="Measure distance between 2 points"
        >
          <Ruler className="w-4 h-4" />
        </button>
        <button
          id="btn-toggle-50m"
          onClick={() => setShow50mCircle(!show50mCircle)}
          className={`p-1.5 rounded-lg transition ${show50mCircle ? 'text-indigo-400 bg-indigo-500/20' : 'text-slate-500 hover:bg-white/10'}`}
          title="Toggle 50m radius overlay"
        >
          <Crosshair className="w-4 h-4" />
        </button>
      </div>

      {/* Distance Measure Display Banner */}
      {measuringMode && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-20 bg-slate-950/95 border border-indigo-500/40 text-white text-xs px-3.5 py-1.5 rounded-full shadow-2xl flex items-center gap-2 animate-fade-in">
          <Ruler className="w-3.5 h-3.5 text-indigo-400" />
          <span>
            {measurePoints.length === 0 && 'Click first location (start pin)'}
            {measurePoints.length === 1 && 'Click second location (end pin)'}
            {measurePoints.length >= 2 && 'Measured distance: '}
            {measureDistanceText && <strong className="text-amber-400 font-mono ml-1">{measureDistanceText}</strong>}
          </span>
          {measurePoints.length > 0 && (
            <button
              onClick={() => {
                setMeasurePoints([]);
                setMeasureDistanceText(null);
              }}
              className="text-slate-400 hover:text-white underline ml-2"
            >
              Reset
            </button>
          )}
        </div>
      )}

      {/* Floating Zoom Controls */}
      <div className="absolute bottom-10 right-3 z-20 flex flex-col gap-1 bg-[#141417]/90 backdrop-blur-md shadow-xl rounded-xl border border-white/10 overflow-hidden">
        <button
          id="btn-zoom-in"
          onClick={() => mapInstanceRef.current?.zoomIn()}
          className="p-2 hover:bg-white/10 active:bg-white/20 text-slate-300 transition"
          title="Zoom In"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <div className="h-[1px] bg-white/10"></div>
        <button
          id="btn-zoom-out"
          onClick={() => mapInstanceRef.current?.zoomOut()}
          className="p-2 hover:bg-white/10 active:bg-white/20 text-slate-300 transition"
          title="Zoom Out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
      </div>

      {/* Map Canvas */}
      <div ref={mapContainerRef} className="w-full h-full z-10" />

      {/* Bottom Coordinates & Scale Status Bar */}
      <div className="absolute bottom-2 left-3 z-20 flex items-center gap-3 bg-[#141417]/90 backdrop-blur-md px-3 py-1 rounded-xl text-[10px] text-slate-400 font-mono border border-white/10 shadow-lg">
        <span className="text-slate-300">{mouseCoords.lat}, {mouseCoords.lng}</span>
        <span className="text-white/20">|</span>
        <span>Zoom: {mouseCoords.zoom}</span>
        {task.viewportAge && (
          <>
            <span className="text-white/20">|</span>
            <span className={`font-semibold ${task.viewportAge === 'FRESH' ? 'text-emerald-400' : 'text-rose-400'}`}>
              VP: {task.viewportAge}
            </span>
          </>
        )}
      </div>
    </div>
  );
};
