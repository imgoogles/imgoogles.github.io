import React, { useState } from 'react';
import { BookOpen, Search, X, ChevronRight, CheckCircle2, FileText } from 'lucide-react';
import { GUIDELINES_CHAPTERS } from '../guidelinesData';

interface GuidelinesHandbookModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GuidelinesHandbookModal: React.FC<GuidelinesHandbookModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedChapterId, setSelectedChapterId] = useState<string>('ch1');

  if (!isOpen) return null;

  const filteredChapters = GUIDELINES_CHAPTERS.filter((ch) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      ch.title.toLowerCase().includes(q) ||
      ch.summary.toLowerCase().includes(q) ||
      ch.rules.some((r) => r.toLowerCase().includes(q)) ||
      ch.examples.some((e) => e.query.toLowerCase().includes(q) || e.explanation.toLowerCase().includes(q))
    );
  });

  const activeChapter = GUIDELINES_CHAPTERS.find((c) => c.id === selectedChapterId) || GUIDELINES_CHAPTERS[0];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#141417] text-slate-200 rounded-2xl shadow-2xl border border-white/10 w-full max-w-4xl overflow-hidden animate-fade-in flex flex-col h-[85vh]">
        {/* Header */}
        <div className="bg-[#0F0F11] px-5 py-3.5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-sm">
            <BookOpen className="w-4 h-4 text-sky-400" />
            <span className="text-white uppercase tracking-wider text-xs">Maps Search Evaluation Guidelines — March 2025 Handbook</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Toolbar */}
        <div className="p-3 bg-[#0A0A0B] border-b border-white/10 flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
            <input
              type="text"
              placeholder="Search guideline rules, e.g. 'unexpected language', 'PERMANENT_CLOSURE', 'campus', '50m'..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#141417] border border-white/10 rounded-xl pl-10 pr-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 font-sans"
            />
          </div>
        </div>

        {/* 2-Column Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left: Chapter list */}
          <div className="w-64 border-r border-white/10 bg-[#0F0F11] overflow-y-auto divide-y divide-white/5 text-xs">
            {filteredChapters.map((ch) => {
              const isSelected = selectedChapterId === ch.id;
              return (
                <button
                  key={ch.id}
                  onClick={() => setSelectedChapterId(ch.id)}
                  className={`w-full text-left p-3.5 flex items-start justify-between gap-2 transition ${
                    isSelected
                      ? 'bg-indigo-600/20 text-indigo-300 font-semibold border-l-4 border-indigo-500'
                      : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
                  }`}
                >
                  <div className="space-y-0.5">
                    <span className="text-[9px] text-slate-500 uppercase tracking-widest block font-mono">
                      Chapter {ch.chapterNumber}
                    </span>
                    <span className="line-clamp-1 text-xs">{ch.title}</span>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 mt-2 shrink-0 ${isSelected ? 'text-indigo-400' : 'text-slate-600'}`} />
                </button>
              );
            })}
          </div>

          {/* Right: Chapter Detail */}
          <div className="flex-1 p-6 overflow-y-auto space-y-5 text-xs text-slate-300">
            <div>
              <span className="text-[10px] font-mono text-indigo-400 font-bold uppercase tracking-widest">
                Chapter {activeChapter.chapterNumber}
              </span>
              <h2 className="text-lg font-bold text-white mt-0.5">{activeChapter.title}</h2>
              <p className="text-slate-400 mt-1 leading-relaxed text-xs">{activeChapter.summary}</p>
            </div>

            {/* Core Rules */}
            <div className="space-y-2">
              <h3 className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Evaluation Rules & Directives</span>
              </h3>
              <ul className="space-y-2">
                {activeChapter.rules.map((rule, idx) => (
                  <li key={idx} className="flex items-start gap-2 bg-[#0A0A0B] p-3 rounded-xl border border-white/5 text-slate-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0"></span>
                    <span className="leading-relaxed">{rule}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Official Examples */}
            {activeChapter.examples.length > 0 && (
              <div className="space-y-2 pt-2">
                <h3 className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-indigo-400" />
                  <span>Official Guideline Examples</span>
                </h3>
                <div className="space-y-2">
                  {activeChapter.examples.map((ex, idx) => (
                    <div key={idx} className="bg-indigo-500/5 border border-indigo-500/20 rounded-xl p-3.5 space-y-1.5">
                      <div className="flex items-center justify-between font-semibold">
                        <span className="font-mono text-indigo-300">Query: {ex.query}</span>
                        <span className="bg-indigo-600/30 text-indigo-200 border border-indigo-500/30 px-2 py-0.5 rounded font-mono text-[10px]">{ex.rating}</span>
                      </div>
                      <div className="text-slate-400">Result: {ex.result}</div>
                      <div className="text-slate-300 pt-1.5 text-[11px] leading-relaxed italic border-t border-indigo-500/20">
                        {ex.explanation}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#0F0F11] px-5 py-3 border-t border-white/10 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-500">Source: Maps Search Evaluation Guidelines (March 2025, 278 pages)</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl font-medium text-xs transition border border-white/10"
          >
            Close Handbook
          </button>
        </div>
      </div>
    </div>
  );
};
