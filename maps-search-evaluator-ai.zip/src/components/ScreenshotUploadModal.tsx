import React, { useState, useEffect, useRef } from 'react';
import { UploadCloud, Image, Sparkles, X, AlertCircle, CheckCircle } from 'lucide-react';
import { TaskData, AIEvaluationResponse } from '../types';

interface ScreenshotUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyParsedTask: (task: TaskData, evaluation: AIEvaluationResponse) => void;
  thinkingMode: boolean;
}

export const ScreenshotUploadModal: React.FC<ScreenshotUploadModalProps> = ({
  isOpen,
  onClose,
  onApplyParsedTask,
  thinkingMode,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isOpen) return;

    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            const reader = new FileReader();
            reader.onload = (event) => {
              setSelectedImage(event.target?.result as string);
              setErrorMsg(null);
            };
            reader.readAsDataURL(blob);
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setSelectedImage(event.target?.result as string);
        setErrorMsg(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setSelectedImage(event.target?.result as string);
        setErrorMsg(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedImage) return;

    setIsAnalyzing(true);
    setErrorMsg(null);

    try {
      const res = await fetch('/api/evaluate-screenshot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: selectedImage,
          useThinking: thinkingMode,
        }),
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to analyze screenshot');
      }

      const rawTask = data.extractedTask;
      const parsedTask: TaskData = {
        taskId: 'SCREENSHOT-TASK-' + Math.floor(Math.random() * 100000),
        taskType: 'Maps_Search_2.0',
        query: rawTask.query || '',
        viewportAge: (rawTask.viewportAge?.toUpperCase() === 'STALE' ? 'STALE' : 'FRESH'),
        locale: rawTask.locale || 'en_US',
        country: rawTask.country || 'United States',
        userLatLng: rawTask.userLatLng || '',
        results: (rawTask.results || []).map((r: any, idx: number) => {
          let lat: number | undefined;
          let lng: number | undefined;
          if (r.latLng) {
            const parts = r.latLng.split(',').map((p: string) => parseFloat(p.trim()));
            if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
              lat = parts[0];
              lng = parts[1];
            }
          }
          return {
            id: `res-${idx + 1}`,
            resultNumber: idx + 1,
            title: r.title || `Result ${idx + 1}`,
            address: r.address || '',
            classification: r.classification || '',
            type: r.type || 'ADDRESS',
            status: r.status || '',
            distanceToUser: r.distanceToUser || '',
            distanceToViewport: r.distanceToViewport || '',
            latLng: r.latLng || '',
            lat,
            lng,
          };
        }),
      };

      if (parsedTask.userLatLng) {
        const parts = parsedTask.userLatLng.split(',').map((p: string) => parseFloat(p.trim()));
        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
          parsedTask.userLat = parts[0];
          parsedTask.userLng = parts[1];
        }
      }

      onApplyParsedTask(parsedTask, data.evaluation);
      onClose();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error processing screenshot.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#141417] text-slate-200 rounded-2xl shadow-2xl border border-white/10 w-full max-w-2xl overflow-hidden animate-fade-in flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="bg-[#0F0F11] px-5 py-3.5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-sm">
            <UploadCloud className="w-4 h-4 text-indigo-400" />
            <span className="text-white uppercase tracking-wider text-xs">Screenshot OCR & Automated Evaluator</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs text-slate-300">
          <p className="text-slate-400 leading-relaxed text-[11px]">
            Take a screenshot of your <strong>TryRating screen</strong> (Win + Shift + S or PrtScn), then{' '}
            <kbd className="px-1.5 py-0.5 bg-white/10 border border-white/20 rounded font-mono text-[11px] font-bold text-indigo-300">
              Ctrl + V
            </kbd>{' '}
            paste it here, or upload an image file. The AI will extract the task details, analyze the map and pins, and auto-populate all rating decisions according to the guidelines!
          </p>

          {/* Drop/Paste Area */}
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition flex flex-col items-center justify-center min-h-[180px] ${
              selectedImage
                ? 'border-indigo-500/50 bg-indigo-500/5'
                : 'border-white/10 hover:border-indigo-500/50 hover:bg-white/5 bg-[#0A0A0B]'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />

            {selectedImage ? (
              <div className="space-y-2 flex flex-col items-center">
                <img
                  src={selectedImage}
                  alt="Pasted TryRating screenshot"
                  className="max-h-48 rounded-xl border border-white/20 shadow-2xl object-contain"
                />
                <span className="text-[11px] text-indigo-400 font-medium">Click or paste another screenshot to replace</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-slate-400">
                <div className="w-12 h-12 rounded-xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center">
                  <Image className="w-6 h-6" />
                </div>
                <div className="font-semibold text-white text-sm">Paste screenshot (Ctrl + V) or Click to Browse</div>
                <div className="text-[11px] text-slate-500">Supports PNG, JPEG, WebP screenshots from TryRating</div>
              </div>
            )}
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-[#0F0F11] px-5 py-3 border-t border-white/10 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-400">
            Engine: {thinkingMode ? 'Gemini 3.1 Pro (High Thinking)' : 'Gemini 3.7 Flash'}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-xl border border-white/10 text-slate-300 hover:bg-white/5 font-medium text-xs transition"
            >
              Cancel
            </button>
            <button
              id="btn-process-screenshot"
              onClick={handleAnalyze}
              disabled={!selectedImage || isAnalyzing}
              className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-semibold flex items-center gap-1.5 shadow-[0_0_15px_rgba(99,102,241,0.4)] transition disabled:opacity-50 cursor-pointer text-xs"
            >
              <Sparkles className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
              <span>{isAnalyzing ? 'Analyzing with Guidelines...' : 'Extract & Auto-Fill'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
