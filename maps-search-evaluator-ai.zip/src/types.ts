export type ViewportAge = 'FRESH' | 'STALE';

export interface TaskResult {
  id: string;
  resultNumber: number;
  title: string;
  address: string;
  classification?: string;
  type?: 'ADDRESS' | 'BUSINESS' | 'POI' | 'TRANSIT' | 'NATURAL_FEATURE' | string;
  status?: string; // e.g. 'PERMANENT_CLOSURE' or ''
  distanceToUser?: string;
  distanceToViewport?: string;
  latLng?: string;
  lat?: number;
  lng?: number;
  additionalInfo?: {
    url?: string;
    phone?: string;
    source?: string;
  };
}

export interface TaskData {
  taskId: string;
  requestId?: string;
  estimatedTime?: string;
  taskType?: string;
  query: string;
  viewportAge: ViewportAge;
  locale: string;
  country: string;
  userLatLng?: string;
  userLat?: number;
  userLng?: number;
  viewportCenterLat?: number;
  viewportCenterLng?: number;
  viewportRadiusKm?: number;
  results: TaskResult[];
}

export type RelevanceRating = 'Navigational' | 'Excellent' | 'Good' | 'Acceptable' | 'Bad' | '';
export type NameAccuracyRating = 'n/a' | 'Correct' | 'Partially Correct' | 'Incorrect' | 'Can\'t Verify' | '';
export type AddressAccuracyRating = 'Correct' | 'Correct with formatting issue' | 'Incorrect' | 'Can\'t Verify' | '';
export type PinAccuracyRating = 'Perfect' | 'Approximate' | 'Next Door' | 'Wrong' | 'Can\'t Verify' | '';

export type AddressIssueType =
  | 'Street Number'
  | 'Unit/Apt'
  | 'Street Name'
  | 'Sub-Locality'
  | 'Locality'
  | 'Region/State'
  | 'Postal Code'
  | 'Country'
  | 'Address does not exist'
  | 'Language/Script issue'
  | 'Country specific issue'
  | 'Other Issue';

export interface SingleResultRating {
  resultIndex: number;
  isUnexpectedLanguage: boolean;
  isClosedOrNonExistent: boolean;
  relevance: RelevanceRating;
  userIntentIssue: boolean;
  distanceProminenceIssue: boolean;
  nameAccuracy: NameAccuracyRating;
  nameIssue: boolean;
  categoryIssue: boolean;
  addressAccuracy: AddressAccuracyRating;
  addressIssues: AddressIssueType[];
  pinAccuracy: PinAccuracyRating;
  pinPreciseLocationIdentified: boolean | null; // Yes / No if Perfect
  comment: string;
}

export interface TaskFormRatingState {
  isNavigational: boolean | null; // Yes / No
  results: Record<number, SingleResultRating>;
}

export interface AIEvaluationResultItem {
  resultIndex: number;
  isUnexpectedLanguage: boolean;
  isClosedOrNonExistent: boolean;
  relevance: RelevanceRating;
  userIntentIssue: boolean;
  distanceProminenceIssue: boolean;
  relevanceExplanation: string;
  nameAccuracy: NameAccuracyRating;
  nameIssue: boolean;
  categoryIssue: boolean;
  nameAccuracyExplanation: string;
  addressAccuracy: AddressAccuracyRating;
  addressIssues: AddressIssueType[];
  addressAccuracyExplanation: string;
  pinAccuracy: PinAccuracyRating;
  pinPreciseLocationIdentified: boolean;
  pinAccuracyExplanation: string;
  suggestedComment: string;
  sourceLinks?: string[];
  guidelineSectionCitations?: string[];
}

export interface AIEvaluationResponse {
  queryAnalysis: {
    intentType: string;
    locationIntent: string;
    explanation: string;
  };
  isNavigational: boolean;
  isNavigationalExplanation: string;
  results: AIEvaluationResultItem[];
}

export interface GuidelineSection {
  id: string;
  chapterNumber: string;
  title: string;
  summary: string;
  rules: string[];
  examples: {
    query: string;
    result: string;
    rating: string;
    explanation: string;
  }[];
}
