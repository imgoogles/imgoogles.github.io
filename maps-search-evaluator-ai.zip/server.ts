import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Lazy init Gemini AI
let aiClient: GoogleGenAI | null = null;
function getAIClient(): GoogleGenAI {
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

const SYSTEM_GUIDELINE_INSTRUCTION = `
You are the world's leading expert evaluator for "Maps Search 2.0" and "Search Relevance" based strictly on the March 2025 "Maps Search Evaluation Guidelines".
Your task is to evaluate Search 2.0 tasks according to all 11 chapters of the official guidelines.

Evaluation Rules Overview:
1. QUERY & USER INTENT:
   - Determine Intent Type: Address query, Specific Address, POI/Business, Chain business, Category query (Clear vs Soft), Product/Service, Transit, Coordinate / "My Location", Routing, or No maps intent (e.g. weather, time, general web -> Bad).
   - Location Intent:
     * Explicit location: If query includes city/state/address (e.g. "kfc philadelphia"), ignore user & viewport locations.
     * Implicit location:
       - Fresh viewport & User Inside: Location intent is User Location. Results inside fresh viewport cannot be rated Bad for distance alone.
       - Fresh viewport & User Outside: Location intent is Fresh Viewport. Results in/near viewport get No distance demotion (eligible for Excellent). If none in viewport, user location is secondary.
       - Stale viewport: Consider user location as location intent (whether user is inside or outside). If user missing, use stale viewport.
       - Viewport age missing: Treat as FRESH.

2. TOP-LEVEL QUESTION: "Is there a navigational result for this query?"
   - Answer "Yes" if there is in the real world a unique, single unambiguous primary entity that completely satisfies the distinct intent (e.g. [Eiffel Tower], complete unique address [717 E El Camino Real...], single-location business, or chain with specific location modifier narrowing to 1 store [Aldi waco tx]).
   - Answer "No" if multiple entities could satisfy (e.g. [starbucks], category [coffee shops], coordinate queries, address that does not exist).

3. RESULT RELEVANCE:
   - Options: Navigational, Excellent, Good, Acceptable, Bad.
   - Demotion Checkboxes (mandatory when rating Good or below):
     * [ ] User intent issue
     * [ ] Distance/Prominence issue
   - Expected vs Unexpected PERMANENT_CLOSURE:
     * Expected closure (e.g. unique POI or all chains closed in area): Rate as if open (Navigational/Excellent), check Business/POI is closed or does not exist.
     * Unexpected closure (e.g. category query or open chain alternatives nearby): Highest rating is Acceptable or Bad (demote by 2).
   - Distance vs Prominence:
     * Many possible results: Demote strictly by distance from user/viewport.
     * Few possible results: Be lenient with distance (e.g. [zara], [Wartestraße]).
     * Rural areas: Generous distance allowance.
   - No maps intent queries: rate Bad (User Intent).
   - Specific address query vs POI result: If query is full address and result is a business at that address -> Navigational/Excellent (adds useful info). If query is business name + address and result is ONLY the address -> Bad (User Intent issue).
   - Query is street name only and result is single business -> Bad (too specific).

4. NAME AND CATEGORY ACCURACY:
   - For Address type results (residential address, street, locality, postal code): Select "n/a".
   - For Business / POI results:
     * Correct: Official name / signs / store locator. Optional location modifier present or omitted is Correct.
     * Partially Correct: Minor misspellings, missing apostrophe (Macys vs Macy's), ALL CAPS when not expected (GAMESTOP), extra non-confusing descriptors (GAP Superstore), corporate structure suffixes on storefront (LLC, Inc.), service-level mismatch. Checkbox: [ ] Name Issue, [ ] Category Issue.
     * Incorrect: Severe misspelling changing meaning (Taco Bull), completely wrong holding name (JAB Holding for Peet's), slang (Mickey D's), wrong category (Macy's categorized as Bar or Shoe Store), wrong language.
     * Can't Verify: Lack of resources online.
   - Category Accuracy: Correct, Incorrect, or N/A.

5. ADDRESS ACCURACY:
   - Options: Correct, Correct with formatting issue, Incorrect, Can't Verify.
   - Address Components (Checkboxes if Incorrect):
     [ ] Street Number, [ ] Unit/Apt, [ ] Street Name, [ ] Sub-Locality, [ ] Locality, [ ] Region/State, [ ] Postal Code, [ ] Country, [ ] Address does not exist, [ ] Language/Script issue, [ ] Country specific issue, [ ] Other issue.
   - Rules:
     * If query address does not exist in real life: Address Accuracy = "Incorrect - Address does not exist", Pin Accuracy = "Can't Verify", Relevance = "Excellent" (if matching query string).
     * POI without expected address (e.g. Park, Transit station, Landmark): Locality is minimum required component. Street number/name not strictly required.
     * Mandatory components: In US, State is mandatory. Country is mandatory if outside test locale.

6. PIN ACCURACY:
   - Options: Perfect, Approximate, Next Door, Wrong, Can't Verify.
   - Single Rooftop:
     * Perfect: Directly on the rooftop of the intended entity. If evidence confirms exact unit/entrance, answer "Yes" to "Does available evidence indicate precise location?". If shared rooftop without unit proof, entire rooftop is Perfect and answer "No".
     * Approximate: On the property parcel / parking lot / auxiliary building (shed/garage).
     * Next Door: On the immediate adjacent property on the same street and block (Tennis rule applies to boundaries; Half 'n Half rule extends to center of street). Note: Shared spaces / strip malls CANNOT have Next Door inside the shared parcel.
     * Wrong: Outside property boundaries or beyond next door.
   - Campus / Complex: Entire campus parcel is Perfect. No Approximate or Next Door.
   - Natural features / Streets: Anywhere on the defining feature / street is Perfect.
   - Coordinate / "My Location": Within 50m radius = Perfect (Relevance = Excellent), outside 50m = Wrong (Relevance = Bad).

7. COMMENTS:
   - Mandatory for any Relevance of Good or below and any Data inaccuracy.
   - Format: Concise English, state inferred user intent, cite guideline reason (e.g. "Demoted -1 for distance", "Incorrect street number: 834 vs 836 per official website"), provide source URL if available, NO personal data (PII).
`;

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Evaluate structured task with Gemini
app.post('/api/evaluate-task', async (req, res) => {
  try {
    const { task, useThinking } = req.body;
    const ai = getAIClient();

    const prompt = `
Analyze this Maps Search Evaluation task according to the March 2025 Guidelines:
Task Data:
${JSON.stringify(task, null, 2)}

Provide a strict, guideline-accurate rating evaluation for this task in JSON format.
Follow every rule regarding query intent, viewport freshness, distance, name accuracy, address accuracy, pin accuracy, and comment syntax.
`;

    const modelName = useThinking ? 'gemini-3.1-pro-preview' : 'gemini-3.7-flash';
    const config: any = {
      systemInstruction: SYSTEM_GUIDELINE_INSTRUCTION,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          queryAnalysis: {
            type: Type.OBJECT,
            properties: {
              intentType: { type: Type.STRING, description: 'Address, POI, Chain, Category, Transit, Coordinate, etc.' },
              locationIntent: { type: Type.STRING, description: 'Explicit or Implicit explanation' },
              explanation: { type: Type.STRING, description: 'Detailed guideline analysis of user intent' },
            },
            required: ['intentType', 'locationIntent', 'explanation'],
          },
          isNavigational: { type: Type.BOOLEAN, description: 'Top-level question: Is there a navigational result in the real world?' },
          isNavigationalExplanation: { type: Type.STRING, description: 'Why Yes or No based on guidelines' },
          results: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                resultIndex: { type: Type.INTEGER },
                isUnexpectedLanguage: { type: Type.BOOLEAN },
                isClosedOrNonExistent: { type: Type.BOOLEAN },
                relevance: { type: Type.STRING, description: 'Navigational, Excellent, Good, Acceptable, or Bad' },
                userIntentIssue: { type: Type.BOOLEAN },
                distanceProminenceIssue: { type: Type.BOOLEAN },
                relevanceExplanation: { type: Type.STRING },
                nameAccuracy: { type: Type.STRING, description: 'n/a, Correct, Partially Correct, Incorrect, or Can\'t Verify' },
                nameIssue: { type: Type.BOOLEAN },
                categoryIssue: { type: Type.BOOLEAN },
                nameAccuracyExplanation: { type: Type.STRING },
                addressAccuracy: { type: Type.STRING, description: 'Correct, Correct with formatting issue, Incorrect, or Can\'t Verify' },
                addressIssues: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: 'List of specific address component issues if Incorrect (e.g. Street Number, Postal Code, Address does not exist)'
                },
                addressAccuracyExplanation: { type: Type.STRING },
                pinAccuracy: { type: Type.STRING, description: 'Perfect, Approximate, Next Door, Wrong, or Can\'t Verify' },
                pinPreciseLocationIdentified: { type: Type.BOOLEAN, description: 'Does available evidence indicate precise location? (if Perfect)' },
                pinAccuracyExplanation: { type: Type.STRING },
                suggestedComment: { type: Type.STRING, description: 'Guideline compliant comment in English' },
                sourceLinks: { type: Type.ARRAY, items: { type: Type.STRING } },
                guidelineSectionCitations: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: [
                'resultIndex',
                'isUnexpectedLanguage',
                'isClosedOrNonExistent',
                'relevance',
                'userIntentIssue',
                'distanceProminenceIssue',
                'relevanceExplanation',
                'nameAccuracy',
                'nameAccuracyExplanation',
                'addressAccuracy',
                'addressAccuracyExplanation',
                'pinAccuracy',
                'pinAccuracyExplanation',
                'suggestedComment'
              ]
            }
          }
        },
        required: ['queryAnalysis', 'isNavigational', 'isNavigationalExplanation', 'results']
      }
    };

    if (useThinking) {
      config.thinkingConfig = { thinkingLevel: ThinkingLevel.HIGH };
    }

    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config,
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    res.json({ success: true, evaluation: parsed });
  } catch (error: any) {
    console.error('Error evaluating task:', error);
    res.status(500).json({ success: false, error: error.message || 'Evaluation failed' });
  }
});

// Evaluate task from uploaded Screenshot (Multimodal Vision)
app.post('/api/evaluate-screenshot', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/png', useThinking } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'Image base64 data required' });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
    const ai = getAIClient();

    const prompt = `
You are analyzing a screenshot of a Maps Search 2.0 evaluation task (such as TryRating platform).
1. Extract all task parameters visible on screen:
   - Query
   - Viewport Age (FRESH or STALE)
   - Locale (e.g. en_US)
   - Country
   - User Lat, Lng
   - Task ID / Request ID if visible
   - Results list: Title, Address, Classification/Type, Status (e.g. PERMANENT_CLOSURE), Distance to User, Distance to Viewport, Lat/Lng
   - Map information: satellite/vector appearance, pin location relative to rooftop/parcel/street, user location marker, viewport bounding box.

2. Perform a complete evaluation adhering strictly to the March 2025 Maps Search Evaluation Guidelines:
   - Query-level Navigational Result question (Yes/No)
   - Result-level checks (Unexpected language, closed/does not exist)
   - Relevance rating (Navigational, Excellent, Good, Acceptable, Bad) + demotion checkboxes
   - Name Accuracy (n/a for address, Correct, Partially Correct, Incorrect, Can't Verify) + checkboxes
   - Address Accuracy (Correct, Correct with formatting, Incorrect, Can't Verify) + component checkboxes
   - Pin Accuracy (Perfect + precise evidence flag, Approximate, Next Door, Wrong, Can't Verify)
   - Concise guideline-compliant comment citing relevant sections.
`;

    const modelName = useThinking ? 'gemini-3.1-pro-preview' : 'gemini-3.7-flash';
    const config: any = {
      systemInstruction: SYSTEM_GUIDELINE_INSTRUCTION,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          extractedTask: {
            type: Type.OBJECT,
            properties: {
              query: { type: Type.STRING },
              viewportAge: { type: Type.STRING },
              locale: { type: Type.STRING },
              country: { type: Type.STRING },
              userLatLng: { type: Type.STRING },
              results: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    address: { type: Type.STRING },
                    classification: { type: Type.STRING },
                    type: { type: Type.STRING },
                    status: { type: Type.STRING },
                    distanceToUser: { type: Type.STRING },
                    distanceToViewport: { type: Type.STRING },
                    latLng: { type: Type.STRING }
                  },
                  required: ['title', 'address']
                }
              }
            },
            required: ['query', 'viewportAge', 'results']
          },
          evaluation: {
            type: Type.OBJECT,
            properties: {
              queryAnalysis: {
                type: Type.OBJECT,
                properties: {
                  intentType: { type: Type.STRING },
                  locationIntent: { type: Type.STRING },
                  explanation: { type: Type.STRING }
                },
                required: ['intentType', 'locationIntent', 'explanation']
              },
              isNavigational: { type: Type.BOOLEAN },
              isNavigationalExplanation: { type: Type.STRING },
              results: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    resultIndex: { type: Type.INTEGER },
                    isUnexpectedLanguage: { type: Type.BOOLEAN },
                    isClosedOrNonExistent: { type: Type.BOOLEAN },
                    relevance: { type: Type.STRING },
                    userIntentIssue: { type: Type.BOOLEAN },
                    distanceProminenceIssue: { type: Type.BOOLEAN },
                    relevanceExplanation: { type: Type.STRING },
                    nameAccuracy: { type: Type.STRING },
                    nameIssue: { type: Type.BOOLEAN },
                    categoryIssue: { type: Type.BOOLEAN },
                    nameAccuracyExplanation: { type: Type.STRING },
                    addressAccuracy: { type: Type.STRING },
                    addressIssues: { type: Type.ARRAY, items: { type: Type.STRING } },
                    addressAccuracyExplanation: { type: Type.STRING },
                    pinAccuracy: { type: Type.STRING },
                    pinPreciseLocationIdentified: { type: Type.BOOLEAN },
                    pinAccuracyExplanation: { type: Type.STRING },
                    suggestedComment: { type: Type.STRING },
                    guidelineSectionCitations: { type: Type.ARRAY, items: { type: Type.STRING } }
                  },
                  required: ['resultIndex', 'relevance', 'nameAccuracy', 'addressAccuracy', 'pinAccuracy', 'suggestedComment']
                }
              }
            },
            required: ['queryAnalysis', 'isNavigational', 'results']
          }
        },
        required: ['extractedTask', 'evaluation']
      }
    };

    if (useThinking) {
      config.thinkingConfig = { thinkingLevel: ThinkingLevel.HIGH };
    }

    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          { inlineData: { mimeType, data: cleanBase64 } },
          { text: prompt }
        ]
      },
      config
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json({ success: true, ...parsed });
  } catch (error: any) {
    console.error('Error analyzing screenshot:', error);
    res.status(500).json({ success: false, error: error.message || 'Screenshot analysis failed' });
  }
});

// Vite middleware setup
async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Maps Search Evaluator AI server running on http://localhost:${PORT}`);
  });
}

start();
